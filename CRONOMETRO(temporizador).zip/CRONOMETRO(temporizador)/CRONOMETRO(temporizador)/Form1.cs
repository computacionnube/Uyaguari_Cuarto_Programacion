﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CRONOMETRO_temporizador_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int dd, ss, mm, hh = 0;
        int fijaA = 0;

        private void btniniciar_Click(object sender, EventArgs e)
        {
            reloj.Start();
        }

        private void reloj_Tick(object sender, EventArgs e)
        {
            string ht, mt, st;
            dd++;
            if (dd == 10)
            {
                dd = 0;
                ss++;
                if (ss == 60)
                {
                    ss = 0;
                    mm++;
                    if (mm == 60)
                    {
                        mm = 0;
                        hh++;
                    }

                }
            }
            if (hh < 16)
            {
                ht = "0" + Convert.ToString(hh);

            }
            else
            {
                ht = Convert.ToString(hh);
            }
            if (mm < 10)
            {
                mt = "0" + Convert.ToString(mm);
            }
            else
            {
                mt = Convert.ToString(mm);
            }
            if (ss < 10)
            {
                st = "0" + Convert.ToString(ss);
            }
            else
            {
                st = Convert.ToString(ss);
            }
            txttiempo.Text = ht + ":" + mt + ":" + st + "." + Convert.ToString(dd);
        }

        private void btndetener_Click(object sender, EventArgs e)
        {
            reloj.Stop();
        }

        private void btnencerar_Click(object sender, EventArgs e)
        {
            reloj.Stop();
            dd = mm = ss = hh = 0;
            txttiempo.Clear();
            txttiempo.Text = "00:00:0.0";
        }

        private void alarma_Tick(object sender, EventArgs e)
        {
            dtpreloj.Value = DateTime.Now;
            if (fijaA == 1)
            {
                if (dtpreloj.Value.Second == dtpFijarH.Value.Second && dtpreloj.Value.Minute == dtpFijarH.Value.Minute && dtpreloj.Value.Hour == dtpFijarH.Value.Hour)
                {
                    fijaA = 0;
                    MessageBox.Show("ALARMA");
                }
            }
        }

        private void btnalarma_Click(object sender, EventArgs e)
        {
            fijaA = 1;
        }
        //bomba

        int bh, bm, bs = 0;
        private void bomba_Tick(object sender, EventArgs e)
        {
            

            bs--;
            if (bs <= 0)
            {
               
                if (bm == 0)
                {
                    bm--;
                    bs = 59;
                    

                }

            }
            if (bm ==0) 
            {
                if (bh > 0)
                {
                    bh--;
                    bh = 59;
                }
            }
            nupdhora.Value = Convert.ToDecimal(bh);
            nupdminuto.Value = Convert.ToDecimal(bm);
            nupdsegundo.Value = Convert.ToDecimal(bs);
            if (bh == 0 && bm == 0 && bs == 0)
            {
                bomba.Stop();
                MessageBox.Show("TERMINO EL TIEMPO USTED ESTA MUERTO","BOMBA",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }
        }

        private void btnactivar_Click(object sender, EventArgs e)
        {
            bs = Convert.ToInt32(nupdsegundo.Value);
            bm = Convert.ToInt32(nupdminuto.Value);
            bh = Convert.ToInt32(nupdhora.Value);
            bomba.Start();
        }

        private void btndescativar_Click(object sender, EventArgs e)
        {
            bomba.Stop();
        }



    }
}

        
    

