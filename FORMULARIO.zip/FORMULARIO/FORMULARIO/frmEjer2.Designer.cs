﻿namespace FORMULARIO
{
    partial class frmEjer2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnCierra2 = new System.Windows.Forms.Button();
            this.lstImagen = new System.Windows.Forms.ImageList(this.components);
            this.relojPantalla = new System.Windows.Forms.Timer(this.components);
            this.pantalla = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pantalla)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCierra2
            // 
            this.btnCierra2.Location = new System.Drawing.Point(386, 303);
            this.btnCierra2.Name = "btnCierra2";
            this.btnCierra2.Size = new System.Drawing.Size(75, 23);
            this.btnCierra2.TabIndex = 1;
            this.btnCierra2.Text = "CERRAR";
            this.btnCierra2.UseVisualStyleBackColor = true;
            this.btnCierra2.Click += new System.EventHandler(this.btnCierra2_Click);
            // 
            // lstImagen
            // 
            this.lstImagen.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // relojPantalla
            // 
            this.relojPantalla.Enabled = true;
            this.relojPantalla.Interval = 1000;
            this.relojPantalla.Tick += new System.EventHandler(this.relojPantalla_Tick);
            // 
            // pantalla
            // 
            this.pantalla.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pantalla.Location = new System.Drawing.Point(66, 33);
            this.pantalla.Name = "pantalla";
            this.pantalla.Size = new System.Drawing.Size(269, 230);
            this.pantalla.TabIndex = 2;
            this.pantalla.TabStop = false;
            
            // 
            // frmEjer2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 348);
            this.Controls.Add(this.pantalla);
            this.Controls.Add(this.btnCierra2);
            this.Name = "frmEjer2";
            this.Text = "frmEjer2";
            ((System.ComponentModel.ISupportInitialize)(this.pantalla)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCierra2;
        private System.Windows.Forms.ImageList lstImagen;
        private System.Windows.Forms.PictureBox pantalla;
        private System.Windows.Forms.Timer relojPantalla;
    }
}