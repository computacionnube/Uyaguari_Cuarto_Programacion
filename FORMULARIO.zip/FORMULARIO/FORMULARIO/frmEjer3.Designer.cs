﻿namespace FORMULARIO
{
    partial class frmEjer3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEjer3));
            this.btnCierra3 = new System.Windows.Forms.Button();
            this.lstA = new System.Windows.Forms.ListBox();
            this.lstB = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPasB = new System.Windows.Forms.Button();
            this.btnPasA = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnlstA = new System.Windows.Forms.Button();
            this.btnlstB = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCierra3
            // 
            this.btnCierra3.Location = new System.Drawing.Point(305, 344);
            this.btnCierra3.Name = "btnCierra3";
            this.btnCierra3.Size = new System.Drawing.Size(75, 23);
            this.btnCierra3.TabIndex = 2;
            this.btnCierra3.Text = "CERRAR";
            this.btnCierra3.UseVisualStyleBackColor = true;
            this.btnCierra3.Click += new System.EventHandler(this.btnCierra3_Click);
            // 
            // lstA
            // 
            this.lstA.FormattingEnabled = true;
            this.lstA.Location = new System.Drawing.Point(33, 147);
            this.lstA.Name = "lstA";
            this.lstA.Size = new System.Drawing.Size(98, 160);
            this.lstA.TabIndex = 3;
            // 
            // lstB
            // 
            this.lstB.FormattingEnabled = true;
            this.lstB.Location = new System.Drawing.Point(275, 147);
            this.lstB.Name = "lstB";
            this.lstB.Size = new System.Drawing.Size(105, 160);
            this.lstB.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "INGRESAR VALOR";
            // 
            // btnPasB
            // 
            this.btnPasB.Image = ((System.Drawing.Image)(resources.GetObject("btnPasB.Image")));
            this.btnPasB.Location = new System.Drawing.Point(159, 193);
            this.btnPasB.Name = "btnPasB";
            this.btnPasB.Size = new System.Drawing.Size(75, 23);
            this.btnPasB.TabIndex = 7;
            this.btnPasB.UseVisualStyleBackColor = true;
            // 
            // btnPasA
            // 
            this.btnPasA.Image = ((System.Drawing.Image)(resources.GetObject("btnPasA.Image")));
            this.btnPasA.Location = new System.Drawing.Point(159, 249);
            this.btnPasA.Name = "btnPasA";
            this.btnPasA.Size = new System.Drawing.Size(75, 23);
            this.btnPasA.TabIndex = 8;
            this.btnPasA.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(149, 61);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 9;
            // 
            // btnlstA
            // 
            this.btnlstA.Location = new System.Drawing.Point(289, 23);
            this.btnlstA.Name = "btnlstA";
            this.btnlstA.Size = new System.Drawing.Size(62, 23);
            this.btnlstA.TabIndex = 11;
            this.btnlstA.Text = "lLISTA A";
            this.btnlstA.UseVisualStyleBackColor = true;
            this.btnlstA.Click += new System.EventHandler(this.btnlstA_Click);
            // 
            // btnlstB
            // 
            this.btnlstB.Location = new System.Drawing.Point(289, 97);
            this.btnlstB.Name = "btnlstB";
            this.btnlstB.Size = new System.Drawing.Size(62, 23);
            this.btnlstB.TabIndex = 12;
            this.btnlstB.Text = "LISTA B";
            this.btnlstB.UseVisualStyleBackColor = true;
            // 
            // frmEjer3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 379);
            this.Controls.Add(this.btnlstB);
            this.Controls.Add(this.btnlstA);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnPasA);
            this.Controls.Add(this.btnPasB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstB);
            this.Controls.Add(this.lstA);
            this.Controls.Add(this.btnCierra3);
            this.Name = "frmEjer3";
            this.Text = "frmEjer3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCierra3;
        private System.Windows.Forms.ListBox lstA;
        private System.Windows.Forms.ListBox lstB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPasB;
        private System.Windows.Forms.Button btnPasA;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnlstA;
        private System.Windows.Forms.Button btnlstB;
    }
}