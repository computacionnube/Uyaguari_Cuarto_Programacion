﻿namespace Temporizador
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnIniciar = new System.Windows.Forms.Button();
            this.btnDetener = new System.Windows.Forms.Button();
            this.btnEncerar = new System.Windows.Forms.Button();
            this.txttiempo = new System.Windows.Forms.TextBox();
            this.reloj = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.dtpTimer = new System.Windows.Forms.DateTimePicker();
            this.Alarma = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.dtpFijarHora = new System.Windows.Forms.DateTimePicker();
            this.btnFijaralarma = new System.Windows.Forms.Button();
            this.NudHoras = new System.Windows.Forms.NumericUpDown();
            this.NudMinutos = new System.Windows.Forms.NumericUpDown();
            this.NudSegundos = new System.Windows.Forms.NumericUpDown();
            this.btnactivar = new System.Windows.Forms.Button();
            this.btnDesactivar = new System.Windows.Forms.Button();
            this.Bomba = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.NudHoras)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudMinutos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudSegundos)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIniciar
            // 
            this.btnIniciar.Location = new System.Drawing.Point(12, 46);
            this.btnIniciar.Name = "btnIniciar";
            this.btnIniciar.Size = new System.Drawing.Size(75, 23);
            this.btnIniciar.TabIndex = 0;
            this.btnIniciar.Text = "Iniciar";
            this.btnIniciar.UseVisualStyleBackColor = true;
            this.btnIniciar.Click += new System.EventHandler(this.btnIniciar_Click);
            // 
            // btnDetener
            // 
            this.btnDetener.Location = new System.Drawing.Point(111, 46);
            this.btnDetener.Name = "btnDetener";
            this.btnDetener.Size = new System.Drawing.Size(75, 23);
            this.btnDetener.TabIndex = 1;
            this.btnDetener.Text = "Detener";
            this.btnDetener.UseVisualStyleBackColor = true;
            this.btnDetener.Click += new System.EventHandler(this.btnDetener_Click);
            // 
            // btnEncerar
            // 
            this.btnEncerar.Location = new System.Drawing.Point(267, 46);
            this.btnEncerar.Name = "btnEncerar";
            this.btnEncerar.Size = new System.Drawing.Size(75, 23);
            this.btnEncerar.TabIndex = 2;
            this.btnEncerar.Text = "Encerar";
            this.btnEncerar.UseVisualStyleBackColor = true;
            this.btnEncerar.Click += new System.EventHandler(this.btnEncerar_Click);
            // 
            // txttiempo
            // 
            this.txttiempo.Location = new System.Drawing.Point(79, 102);
            this.txttiempo.Name = "txttiempo";
            this.txttiempo.Size = new System.Drawing.Size(107, 20);
            this.txttiempo.TabIndex = 3;
            this.txttiempo.Text = "00.00.00.0";
            this.txttiempo.TextChanged += new System.EventHandler(this.txttiempo_TextChanged);
            // 
            // reloj
            // 
            this.reloj.Interval = 10;
            this.reloj.Tick += new System.EventHandler(this.reloj_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 154);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Reloj ";
            // 
            // dtpTimer
            // 
            this.dtpTimer.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpTimer.Location = new System.Drawing.Point(91, 154);
            this.dtpTimer.Name = "dtpTimer";
            this.dtpTimer.Size = new System.Drawing.Size(200, 20);
            this.dtpTimer.TabIndex = 5;
            this.dtpTimer.ValueChanged += new System.EventHandler(this.dtpTimer_ValueChanged);
            // 
            // Alarma
            // 
            this.Alarma.Enabled = true;
            this.Alarma.Tick += new System.EventHandler(this.Alarma_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Fijar Hora";
            // 
            // dtpFijarHora
            // 
            this.dtpFijarHora.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpFijarHora.Location = new System.Drawing.Point(92, 192);
            this.dtpFijarHora.Name = "dtpFijarHora";
            this.dtpFijarHora.ShowUpDown = true;
            this.dtpFijarHora.Size = new System.Drawing.Size(200, 20);
            this.dtpFijarHora.TabIndex = 7;
            this.dtpFijarHora.ValueChanged += new System.EventHandler(this.dtpFijaHora_ValueChanged);
            // 
            // btnFijaralarma
            // 
            this.btnFijaralarma.Location = new System.Drawing.Point(297, 159);
            this.btnFijaralarma.Name = "btnFijaralarma";
            this.btnFijaralarma.Size = new System.Drawing.Size(87, 53);
            this.btnFijaralarma.TabIndex = 8;
            this.btnFijaralarma.Text = "Fijar Alarma";
            this.btnFijaralarma.UseVisualStyleBackColor = true;
            this.btnFijaralarma.Click += new System.EventHandler(this.btnFijaralarma_Click);
            // 
            // NudHoras
            // 
            this.NudHoras.Enabled = false;
            this.NudHoras.Location = new System.Drawing.Point(53, 233);
            this.NudHoras.Name = "NudHoras";
            this.NudHoras.Size = new System.Drawing.Size(33, 20);
            this.NudHoras.TabIndex = 9;
            // 
            // NudMinutos
            // 
            this.NudMinutos.Location = new System.Drawing.Point(92, 233);
            this.NudMinutos.Name = "NudMinutos";
            this.NudMinutos.Size = new System.Drawing.Size(48, 20);
            this.NudMinutos.TabIndex = 10;
            // 
            // NudSegundos
            // 
            this.NudSegundos.Location = new System.Drawing.Point(146, 233);
            this.NudSegundos.Name = "NudSegundos";
            this.NudSegundos.Size = new System.Drawing.Size(48, 20);
            this.NudSegundos.TabIndex = 11;
            // 
            // btnactivar
            // 
            this.btnactivar.Location = new System.Drawing.Point(297, 218);
            this.btnactivar.Name = "btnactivar";
            this.btnactivar.Size = new System.Drawing.Size(75, 23);
            this.btnactivar.TabIndex = 12;
            this.btnactivar.Text = "Activar";
            this.btnactivar.UseVisualStyleBackColor = true;
            this.btnactivar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDesactivar
            // 
            this.btnDesactivar.Location = new System.Drawing.Point(297, 247);
            this.btnDesactivar.Name = "btnDesactivar";
            this.btnDesactivar.Size = new System.Drawing.Size(75, 23);
            this.btnDesactivar.TabIndex = 13;
            this.btnDesactivar.Text = "Desactivar";
            this.btnDesactivar.UseVisualStyleBackColor = true;
            this.btnDesactivar.Click += new System.EventHandler(this.btnDesactivar_Click);
            // 
            // Bomba
            // 
            this.Bomba.Tick += new System.EventHandler(this.Bomba_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 365);
            this.Controls.Add(this.btnDesactivar);
            this.Controls.Add(this.btnactivar);
            this.Controls.Add(this.NudSegundos);
            this.Controls.Add(this.NudMinutos);
            this.Controls.Add(this.NudHoras);
            this.Controls.Add(this.btnFijaralarma);
            this.Controls.Add(this.dtpFijarHora);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpTimer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txttiempo);
            this.Controls.Add(this.btnEncerar);
            this.Controls.Add(this.btnDetener);
            this.Controls.Add(this.btnIniciar);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.NudHoras)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudMinutos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudSegundos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIniciar;
        private System.Windows.Forms.Button btnDetener;
        private System.Windows.Forms.Button btnEncerar;
        private System.Windows.Forms.TextBox txttiempo;
        private System.Windows.Forms.Timer reloj;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpTimer;
        private System.Windows.Forms.Timer Alarma;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpFijarHora;
        private System.Windows.Forms.Button btnFijaralarma;
        private System.Windows.Forms.NumericUpDown NudHoras;
        private System.Windows.Forms.NumericUpDown NudMinutos;
        private System.Windows.Forms.NumericUpDown NudSegundos;
        private System.Windows.Forms.Button btnactivar;
        private System.Windows.Forms.Button btnDesactivar;
        private System.Windows.Forms.Timer Bomba;
    }
}

