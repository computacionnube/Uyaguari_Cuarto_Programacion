﻿namespace PRUEBA_BIMESTRAL_Jason_Uyaguari_
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtapell1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.TxtNumTel1 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txtRecide = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.TxtdomPost = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.txtExpedPor = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txtValidHast = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txtFechaEXpide = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txtNumDocViaje = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txtotros = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.rbpasofic = new System.Windows.Forms.RadioButton();
            this.rbpasotros = new System.Windows.Forms.RadioButton();
            this.rbpasespec = new System.Windows.Forms.RadioButton();
            this.rbpasdiplo = new System.Windows.Forms.RadioButton();
            this.rbpasServi = new System.Windows.Forms.RadioButton();
            this.rbpasordi = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtnumDocnaciosiProced = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtNacPersoEjerce = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtdirec2 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtnombre2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtApellido3 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.cboestadocivil = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btmujer = new System.Windows.Forms.RadioButton();
            this.btvaron = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtNacionACT = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtpaisNac = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtLugNaci = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtFecha1 = new System.Windows.Forms.TextBox();
            this.txtaño = new System.Windows.Forms.TextBox();
            this.txtMes = new System.Windows.Forms.TextBox();
            this.txtDia = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtnomb1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtapell2 = new System.Windows.Forms.TextBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.dgvdato = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apell1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombre1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FechaNaimi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lugnaci = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paisNci = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NacionalACT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sexo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estciv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apell3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomb2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.direcmen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nacionPersoAcargo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Numdocmentonacio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tipodedocviaje = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Numdocviaje = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaexped = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Validhast = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Expedidopor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Domipos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Correo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.residentdeunpaisdistintdelactual = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numtelefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.btnbuscar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdato)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Apellido(s)";
            // 
            // txtapell1
            // 
            this.txtapell1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtapell1.Location = new System.Drawing.Point(3, 54);
            this.txtapell1.Name = "txtapell1";
            this.txtapell1.Size = new System.Drawing.Size(433, 20);
            this.txtapell1.TabIndex = 1;
            this.txtapell1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtapell1_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Apellido(s)";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.panel15);
            this.panel1.Controls.Add(this.panel14);
            this.panel1.Controls.Add(this.panel13);
            this.panel1.Controls.Add(this.panel12);
            this.panel1.Controls.Add(this.panel11);
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.txtnomb1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtapell2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtapell1);
            this.panel1.Location = new System.Drawing.Point(52, 139);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1241, 591);
            this.panel1.TabIndex = 4;
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel15.Controls.Add(this.TxtNumTel1);
            this.panel15.Controls.Add(this.label29);
            this.panel15.Location = new System.Drawing.Point(674, 450);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(183, 70);
            this.panel15.TabIndex = 19;
            // 
            // TxtNumTel1
            // 
            this.TxtNumTel1.Location = new System.Drawing.Point(17, 40);
            this.TxtNumTel1.Name = "TxtNumTel1";
            this.TxtNumTel1.Size = new System.Drawing.Size(148, 20);
            this.TxtNumTel1.TabIndex = 9;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(23, 15);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(104, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "Numero de Telefono";
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel14.Controls.Add(this.txtRecide);
            this.panel14.Controls.Add(this.label28);
            this.panel14.Controls.Add(this.label27);
            this.panel14.Controls.Add(this.txtCorreo);
            this.panel14.Controls.Add(this.TxtdomPost);
            this.panel14.Controls.Add(this.label26);
            this.panel14.Location = new System.Drawing.Point(3, 450);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(463, 144);
            this.panel14.TabIndex = 19;
            // 
            // txtRecide
            // 
            this.txtRecide.Location = new System.Drawing.Point(26, 102);
            this.txtRecide.Name = "txtRecide";
            this.txtRecide.Size = new System.Drawing.Size(302, 20);
            this.txtRecide.TabIndex = 13;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(23, 86);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(294, 13);
            this.label28.TabIndex = 12;
            this.label28.Text = "Residente de un país distinto del pais de nacionalidad actual";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(23, 55);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(222, 13);
            this.label27.TabIndex = 11;
            this.label27.Text = "Direccion de correo electronico del solicitante";
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(251, 41);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(182, 20);
            this.txtCorreo.TabIndex = 10;
            // 
            // TxtdomPost
            // 
            this.TxtdomPost.Location = new System.Drawing.Point(126, 15);
            this.TxtdomPost.Name = "TxtdomPost";
            this.TxtdomPost.Size = new System.Drawing.Size(182, 20);
            this.TxtdomPost.TabIndex = 9;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(23, 15);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(83, 13);
            this.label26.TabIndex = 0;
            this.label26.Text = "Domicilio postal ";
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel13.Controls.Add(this.txtExpedPor);
            this.panel13.Controls.Add(this.label25);
            this.panel13.Location = new System.Drawing.Point(472, 450);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(183, 70);
            this.panel13.TabIndex = 18;
            // 
            // txtExpedPor
            // 
            this.txtExpedPor.Location = new System.Drawing.Point(17, 40);
            this.txtExpedPor.Name = "txtExpedPor";
            this.txtExpedPor.Size = new System.Drawing.Size(148, 20);
            this.txtExpedPor.TabIndex = 9;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(23, 15);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(69, 13);
            this.label25.TabIndex = 0;
            this.label25.Text = "Expedido por";
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel12.Controls.Add(this.txtValidHast);
            this.panel12.Controls.Add(this.label24);
            this.panel12.Location = new System.Drawing.Point(863, 374);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(183, 70);
            this.panel12.TabIndex = 17;
            // 
            // txtValidHast
            // 
            this.txtValidHast.Location = new System.Drawing.Point(17, 40);
            this.txtValidHast.Name = "txtValidHast";
            this.txtValidHast.Size = new System.Drawing.Size(148, 20);
            this.txtValidHast.TabIndex = 9;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(23, 15);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "Valido hasta";
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel11.Controls.Add(this.txtFechaEXpide);
            this.panel11.Controls.Add(this.label22);
            this.panel11.Location = new System.Drawing.Point(674, 374);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(183, 70);
            this.panel11.TabIndex = 16;
            // 
            // txtFechaEXpide
            // 
            this.txtFechaEXpide.Location = new System.Drawing.Point(17, 40);
            this.txtFechaEXpide.Name = "txtFechaEXpide";
            this.txtFechaEXpide.Size = new System.Drawing.Size(148, 20);
            this.txtFechaEXpide.TabIndex = 9;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(23, 15);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(103, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "fecha de expedicion";
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel10.Controls.Add(this.txtNumDocViaje);
            this.panel10.Controls.Add(this.label23);
            this.panel10.Location = new System.Drawing.Point(472, 374);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(183, 70);
            this.panel10.TabIndex = 15;
            // 
            // txtNumDocViaje
            // 
            this.txtNumDocViaje.Location = new System.Drawing.Point(17, 40);
            this.txtNumDocViaje.Name = "txtNumDocViaje";
            this.txtNumDocViaje.Size = new System.Drawing.Size(148, 20);
            this.txtNumDocViaje.TabIndex = 9;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(23, 15);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(142, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "Numero documento del viaje";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel9.Controls.Add(this.txtotros);
            this.panel9.Controls.Add(this.label21);
            this.panel9.Controls.Add(this.rbpasofic);
            this.panel9.Controls.Add(this.rbpasotros);
            this.panel9.Controls.Add(this.rbpasespec);
            this.panel9.Controls.Add(this.rbpasdiplo);
            this.panel9.Controls.Add(this.rbpasServi);
            this.panel9.Controls.Add(this.rbpasordi);
            this.panel9.Controls.Add(this.label20);
            this.panel9.Location = new System.Drawing.Point(3, 307);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(463, 133);
            this.panel9.TabIndex = 14;
            // 
            // txtotros
            // 
            this.txtotros.Enabled = false;
            this.txtotros.Location = new System.Drawing.Point(283, 106);
            this.txtotros.Name = "txtotros";
            this.txtotros.Size = new System.Drawing.Size(148, 20);
            this.txtotros.TabIndex = 9;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(285, 85);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(62, 13);
            this.label21.TabIndex = 8;
            this.label21.Text = "Especifique";
            // 
            // rbpasofic
            // 
            this.rbpasofic.AutoSize = true;
            this.rbpasofic.Location = new System.Drawing.Point(11, 60);
            this.rbpasofic.Name = "rbpasofic";
            this.rbpasofic.Size = new System.Drawing.Size(105, 17);
            this.rbpasofic.TabIndex = 7;
            this.rbpasofic.TabStop = true;
            this.rbpasofic.Text = "Pasaporte Oficial";
            this.rbpasofic.UseVisualStyleBackColor = true;
            this.rbpasofic.CheckedChanged += new System.EventHandler(this.rbpasofic_CheckedChanged);
            // 
            // rbpasotros
            // 
            this.rbpasotros.AutoSize = true;
            this.rbpasotros.Location = new System.Drawing.Point(288, 65);
            this.rbpasotros.Name = "rbpasotros";
            this.rbpasotros.Size = new System.Drawing.Size(45, 17);
            this.rbpasotros.TabIndex = 6;
            this.rbpasotros.TabStop = true;
            this.rbpasotros.Text = "Otro";
            this.rbpasotros.UseVisualStyleBackColor = true;
            this.rbpasotros.CheckedChanged += new System.EventHandler(this.rbpasotros_CheckedChanged);
            // 
            // rbpasespec
            // 
            this.rbpasespec.AutoSize = true;
            this.rbpasespec.Location = new System.Drawing.Point(141, 65);
            this.rbpasespec.Name = "rbpasespec";
            this.rbpasespec.Size = new System.Drawing.Size(110, 17);
            this.rbpasespec.TabIndex = 5;
            this.rbpasespec.TabStop = true;
            this.rbpasespec.Text = "Pasporte Especial";
            this.rbpasespec.UseVisualStyleBackColor = true;
            this.rbpasespec.CheckedChanged += new System.EventHandler(this.rbpasespec_CheckedChanged);
            // 
            // rbpasdiplo
            // 
            this.rbpasdiplo.AutoSize = true;
            this.rbpasdiplo.Location = new System.Drawing.Point(141, 42);
            this.rbpasdiplo.Name = "rbpasdiplo";
            this.rbpasdiplo.Size = new System.Drawing.Size(131, 17);
            this.rbpasdiplo.TabIndex = 4;
            this.rbpasdiplo.TabStop = true;
            this.rbpasdiplo.Text = "Pasaporte Diplomatico";
            this.rbpasdiplo.UseVisualStyleBackColor = true;
            this.rbpasdiplo.CheckedChanged += new System.EventHandler(this.rbpasdiplo_CheckedChanged);
            // 
            // rbpasServi
            // 
            this.rbpasServi.AutoSize = true;
            this.rbpasServi.Location = new System.Drawing.Point(288, 42);
            this.rbpasServi.Name = "rbpasServi";
            this.rbpasServi.Size = new System.Drawing.Size(129, 17);
            this.rbpasServi.TabIndex = 3;
            this.rbpasServi.TabStop = true;
            this.rbpasServi.Text = "Pasaporte de Servicio";
            this.rbpasServi.UseVisualStyleBackColor = true;
            this.rbpasServi.CheckedChanged += new System.EventHandler(this.rbpasServi_CheckedChanged);
            // 
            // rbpasordi
            // 
            this.rbpasordi.AutoSize = true;
            this.rbpasordi.Location = new System.Drawing.Point(17, 37);
            this.rbpasordi.Name = "rbpasordi";
            this.rbpasordi.Size = new System.Drawing.Size(118, 17);
            this.rbpasordi.TabIndex = 2;
            this.rbpasordi.TabStop = true;
            this.rbpasordi.Text = "Pasaporte Ordinario";
            this.rbpasordi.UseVisualStyleBackColor = true;
            this.rbpasordi.CheckedChanged += new System.EventHandler(this.rbpasordi_CheckedChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(23, 15);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(143, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "Tipo del documento del viaje";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel8.Controls.Add(this.txtnumDocnaciosiProced);
            this.panel8.Controls.Add(this.label19);
            this.panel8.Location = new System.Drawing.Point(3, 243);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(463, 61);
            this.panel8.TabIndex = 13;
            // 
            // txtnumDocnaciosiProced
            // 
            this.txtnumDocnaciosiProced.Location = new System.Drawing.Point(26, 32);
            this.txtnumDocnaciosiProced.Name = "txtnumDocnaciosiProced";
            this.txtnumDocnaciosiProced.Size = new System.Drawing.Size(173, 20);
            this.txtnumDocnaciosiProced.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(23, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(276, 13);
            this.label19.TabIndex = 0;
            this.label19.Text = "Numero del documento nacional de identidad, si procede";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel7.Controls.Add(this.txtNacPersoEjerce);
            this.panel7.Controls.Add(this.label18);
            this.panel7.Controls.Add(this.txtdirec2);
            this.panel7.Controls.Add(this.label17);
            this.panel7.Controls.Add(this.txtnombre2);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Controls.Add(this.txtApellido3);
            this.panel7.Controls.Add(this.label15);
            this.panel7.Controls.Add(this.label13);
            this.panel7.Location = new System.Drawing.Point(472, 187);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(726, 181);
            this.panel7.TabIndex = 13;
            // 
            // txtNacPersoEjerce
            // 
            this.txtNacPersoEjerce.Location = new System.Drawing.Point(348, 45);
            this.txtNacPersoEjerce.Name = "txtNacPersoEjerce";
            this.txtNacPersoEjerce.Size = new System.Drawing.Size(325, 20);
            this.txtNacPersoEjerce.TabIndex = 14;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(345, 16);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(348, 13);
            this.label18.TabIndex = 13;
            this.label18.Text = "Nacionalidad de la persona que ejerce la patria potestad o del tutor legal";
            // 
            // txtdirec2
            // 
            this.txtdirec2.Location = new System.Drawing.Point(12, 148);
            this.txtdirec2.Name = "txtdirec2";
            this.txtdirec2.Size = new System.Drawing.Size(320, 20);
            this.txtdirec2.TabIndex = 12;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(28, 123);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 13);
            this.label17.TabIndex = 11;
            this.label17.Text = "Diereccion";
            // 
            // txtnombre2
            // 
            this.txtnombre2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtnombre2.Location = new System.Drawing.Point(12, 88);
            this.txtnombre2.Name = "txtnombre2";
            this.txtnombre2.Size = new System.Drawing.Size(320, 20);
            this.txtnombre2.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(28, 72);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "Nombre(s)";
            // 
            // txtApellido3
            // 
            this.txtApellido3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtApellido3.Location = new System.Drawing.Point(12, 49);
            this.txtApellido3.Name = "txtApellido3";
            this.txtApellido3.Size = new System.Drawing.Size(320, 20);
            this.txtApellido3.TabIndex = 8;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(28, 33);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "Apellido(s)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "MENOR DE EDAD";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.cboestadocivil);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Location = new System.Drawing.Point(246, 176);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(200, 61);
            this.panel6.TabIndex = 12;
            // 
            // cboestadocivil
            // 
            this.cboestadocivil.FormattingEnabled = true;
            this.cboestadocivil.Items.AddRange(new object[] {
            "SOLTERO(A)",
            "CASADO(A)",
            "DIVORCIADO(A)",
            "VIUDO(A)"});
            this.cboestadocivil.Location = new System.Drawing.Point(45, 31);
            this.cboestadocivil.Name = "cboestadocivil";
            this.cboestadocivil.Size = new System.Drawing.Size(121, 21);
            this.cboestadocivil.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(60, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "ESTADO CIVIL";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.btmujer);
            this.panel5.Controls.Add(this.btvaron);
            this.panel5.Controls.Add(this.label16);
            this.panel5.Location = new System.Drawing.Point(3, 176);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(227, 61);
            this.panel5.TabIndex = 11;
            // 
            // btmujer
            // 
            this.btmujer.AutoSize = true;
            this.btmujer.Location = new System.Drawing.Point(126, 27);
            this.btmujer.Name = "btmujer";
            this.btmujer.Size = new System.Drawing.Size(62, 17);
            this.btmujer.TabIndex = 2;
            this.btmujer.TabStop = true;
            this.btmujer.Text = "MUJER";
            this.btmujer.UseVisualStyleBackColor = true;
            // 
            // btvaron
            // 
            this.btvaron.AutoSize = true;
            this.btvaron.Location = new System.Drawing.Point(11, 27);
            this.btvaron.Name = "btvaron";
            this.btvaron.Size = new System.Drawing.Size(63, 17);
            this.btvaron.TabIndex = 1;
            this.btvaron.TabStop = true;
            this.btvaron.Text = "VARON";
            this.btvaron.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(80, 9);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(36, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "SEXO";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.txtNacionACT);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Location = new System.Drawing.Point(971, 50);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(227, 131);
            this.panel4.TabIndex = 13;
            // 
            // txtNacionACT
            // 
            this.txtNacionACT.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNacionACT.Location = new System.Drawing.Point(25, 36);
            this.txtNacionACT.Name = "txtNacionACT";
            this.txtNacionACT.Size = new System.Drawing.Size(169, 20);
            this.txtNacionACT.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(42, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "NACIONALIDAD ACTUAL";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.txtpaisNac);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.txtLugNaci);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Location = new System.Drawing.Point(715, 50);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(227, 131);
            this.panel3.TabIndex = 11;
            // 
            // txtpaisNac
            // 
            this.txtpaisNac.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtpaisNac.Location = new System.Drawing.Point(29, 86);
            this.txtpaisNac.Name = "txtpaisNac";
            this.txtpaisNac.Size = new System.Drawing.Size(169, 20);
            this.txtpaisNac.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(47, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "PAIS DE NACIMIENTO";
            // 
            // txtLugNaci
            // 
            this.txtLugNaci.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtLugNaci.Location = new System.Drawing.Point(29, 33);
            this.txtLugNaci.Name = "txtLugNaci";
            this.txtLugNaci.Size = new System.Drawing.Size(169, 20);
            this.txtLugNaci.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(42, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(132, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "LUGAR DE NACIMIENTO";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.txtFecha1);
            this.panel2.Controls.Add(this.txtaño);
            this.panel2.Controls.Add(this.txtMes);
            this.panel2.Controls.Add(this.txtDia);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(472, 50);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(227, 131);
            this.panel2.TabIndex = 7;
            // 
            // txtFecha1
            // 
            this.txtFecha1.Location = new System.Drawing.Point(45, 99);
            this.txtFecha1.Name = "txtFecha1";
            this.txtFecha1.Size = new System.Drawing.Size(118, 20);
            this.txtFecha1.TabIndex = 10;
            // 
            // txtaño
            // 
            this.txtaño.Location = new System.Drawing.Point(152, 62);
            this.txtaño.Name = "txtaño";
            this.txtaño.Size = new System.Drawing.Size(36, 20);
            this.txtaño.TabIndex = 9;
            this.txtaño.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtaño_KeyPress);
            // 
            // txtMes
            // 
            this.txtMes.Location = new System.Drawing.Point(84, 62);
            this.txtMes.Name = "txtMes";
            this.txtMes.Size = new System.Drawing.Size(36, 20);
            this.txtMes.TabIndex = 8;
            this.txtMes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMes_KeyPress);
            // 
            // txtDia
            // 
            this.txtDia.Location = new System.Drawing.Point(11, 62);
            this.txtDia.Name = "txtDia";
            this.txtDia.Size = new System.Drawing.Size(36, 20);
            this.txtDia.TabIndex = 7;
            this.txtDia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDia_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(158, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "AÑO";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(81, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "MES";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(25, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "DIA";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "FECHA DE NACIMIENTO";
            // 
            // txtnomb1
            // 
            this.txtnomb1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtnomb1.Location = new System.Drawing.Point(3, 150);
            this.txtnomb1.Name = "txtnomb1";
            this.txtnomb1.Size = new System.Drawing.Size(433, 20);
            this.txtnomb1.TabIndex = 6;
            this.txtnomb1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnomb1_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Nombre(s)";
            // 
            // txtapell2
            // 
            this.txtapell2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtapell2.Location = new System.Drawing.Point(3, 102);
            this.txtapell2.Name = "txtapell2";
            this.txtapell2.Size = new System.Drawing.Size(433, 20);
            this.txtapell2.TabIndex = 4;
            this.txtapell2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtapell2_KeyPress);
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel18.Controls.Add(this.label32);
            this.panel18.Location = new System.Drawing.Point(338, 2);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(871, 131);
            this.panel18.TabIndex = 12;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(317, 52);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(427, 42);
            this.label32.TabIndex = 1;
            this.label32.Text = "SOLICITUD DE VISADO";
            // 
            // panel20
            // 
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel20.Controls.Add(this.pictureBox2);
            this.panel20.Controls.Add(this.radioButton22);
            this.panel20.Controls.Add(this.radioButton21);
            this.panel20.Controls.Add(this.label36);
            this.panel20.Controls.Add(this.label35);
            this.panel20.Controls.Add(this.label34);
            this.panel20.Controls.Add(this.radioButton20);
            this.panel20.Controls.Add(this.radioButton19);
            this.panel20.Controls.Add(this.radioButton18);
            this.panel20.Controls.Add(this.radioButton17);
            this.panel20.Controls.Add(this.radioButton16);
            this.panel20.Controls.Add(this.radioButton15);
            this.panel20.Controls.Add(this.textBox27);
            this.panel20.Controls.Add(this.label31);
            this.panel20.Controls.Add(this.radioButton14);
            this.panel20.Controls.Add(this.radioButton13);
            this.panel20.Controls.Add(this.radioButton12);
            this.panel20.Controls.Add(this.radioButton11);
            this.panel20.Controls.Add(this.radioButton10);
            this.panel20.Controls.Add(this.radioButton9);
            this.panel20.Controls.Add(this.textBox26);
            this.panel20.Controls.Add(this.label30);
            this.panel20.Controls.Add(this.textBox25);
            this.panel20.Controls.Add(this.label3);
            this.panel20.Controls.Add(this.textBox29);
            this.panel20.Controls.Add(this.label33);
            this.panel20.Location = new System.Drawing.Point(1311, 12);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(293, 765);
            this.panel20.TabIndex = 14;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Location = new System.Drawing.Point(6, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(145, 101);
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(27, 730);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(69, 17);
            this.radioButton22.TabIndex = 34;
            this.radioButton22.TabStop = true;
            this.radioButton22.Text = "Expedido";
            this.radioButton22.UseVisualStyleBackColor = true;
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Location = new System.Drawing.Point(25, 699);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(75, 17);
            this.radioButton21.TabIndex = 33;
            this.radioButton21.TabStop = true;
            this.radioButton21.Text = "Denegado";
            this.radioButton21.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(3, 665);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(122, 13);
            this.label36.TabIndex = 32;
            this.label36.Text = "Decision sobre el visado";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(3, 496);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(118, 13);
            this.label35.TabIndex = 31;
            this.label35.Text = "Documento presentado";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(3, 125);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(162, 13);
            this.label34.TabIndex = 30;
            this.label34.Text = "Numero de la solicitud del visado";
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(25, 630);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(50, 17);
            this.radioButton20.TabIndex = 29;
            this.radioButton20.TabStop = true;
            this.radioButton20.Text = "Otros";
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(25, 607);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(136, 17);
            this.radioButton19.TabIndex = 28;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "Seguro medico de viaje";
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(25, 561);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(71, 17);
            this.radioButton18.TabIndex = 27;
            this.radioButton18.TabStop = true;
            this.radioButton18.Text = "Invitacion";
            this.radioButton18.UseVisualStyleBackColor = true;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(25, 516);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(125, 17);
            this.radioButton17.TabIndex = 26;
            this.radioButton17.TabStop = true;
            this.radioButton17.Text = "Documentos de viaje";
            this.radioButton17.UseVisualStyleBackColor = true;
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(27, 584);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(124, 17);
            this.radioButton16.TabIndex = 25;
            this.radioButton16.TabStop = true;
            this.radioButton16.Text = "Medios de transporte";
            this.radioButton16.UseVisualStyleBackColor = true;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(25, 538);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(130, 17);
            this.radioButton15.TabIndex = 24;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "Medios de subsitencia";
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(3, 451);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(169, 20);
            this.textBox27.TabIndex = 22;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(3, 411);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(132, 13);
            this.label31.TabIndex = 21;
            this.label31.Text = "expediente gestionado por";
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(25, 383);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(50, 17);
            this.radioButton14.TabIndex = 20;
            this.radioButton14.TabStop = true;
            this.radioButton14.Text = "Otros";
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(25, 279);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(132, 17);
            this.radioButton13.TabIndex = 19;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "intermediario comercial";
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(25, 303);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(61, 17);
            this.radioButton12.TabIndex = 18;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "frontera";
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(27, 230);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(46, 17);
            this.radioButton11.TabIndex = 17;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "CSS";
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(27, 204);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(123, 17);
            this.radioButton10.TabIndex = 16;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "enbajada/consulado";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(27, 252);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(133, 17);
            this.radioButton9.TabIndex = 15;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "Proveedor de servicios";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(3, 357);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(169, 20);
            this.textBox26.TabIndex = 14;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(0, 325);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(49, 13);
            this.label30.TabIndex = 13;
            this.label30.Text = "Nombres";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(6, 181);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(169, 20);
            this.textBox25.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Fecha de la solicitud";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(3, 142);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(169, 20);
            this.textBox29.TabIndex = 10;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(49, 107);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(172, 13);
            this.label33.TabIndex = 0;
            this.label33.Text = "Parte reservada a la administracion";
            // 
            // dgvdato
            // 
            this.dgvdato.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvdato.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.apell1,
            this.nombre1,
            this.FechaNaimi,
            this.lugnaci,
            this.paisNci,
            this.NacionalACT,
            this.Sexo,
            this.estciv,
            this.apell3,
            this.nomb2,
            this.direcmen,
            this.nacionPersoAcargo,
            this.Numdocmentonacio,
            this.Tipodedocviaje,
            this.Numdocviaje,
            this.fechaexped,
            this.Validhast,
            this.Expedidopor,
            this.Domipos,
            this.Correo,
            this.residentdeunpaisdistintdelactual,
            this.numtelefono});
            this.dgvdato.Location = new System.Drawing.Point(57, 753);
            this.dgvdato.Name = "dgvdato";
            this.dgvdato.Size = new System.Drawing.Size(1144, 109);
            this.dgvdato.TabIndex = 15;
            this.dgvdato.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvdato_CellClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "#";
            this.Column1.Name = "Column1";
            // 
            // apell1
            // 
            this.apell1.HeaderText = "Apellido(s)";
            this.apell1.Name = "apell1";
            // 
            // nombre1
            // 
            this.nombre1.HeaderText = "Nombres(s)";
            this.nombre1.Name = "nombre1";
            // 
            // FechaNaimi
            // 
            this.FechaNaimi.HeaderText = "Fecha de nacimiento";
            this.FechaNaimi.Name = "FechaNaimi";
            // 
            // lugnaci
            // 
            this.lugnaci.HeaderText = "Lugar de nacimineto";
            this.lugnaci.Name = "lugnaci";
            // 
            // paisNci
            // 
            this.paisNci.HeaderText = "Pais de nacimiento";
            this.paisNci.Name = "paisNci";
            // 
            // NacionalACT
            // 
            this.NacionalACT.HeaderText = "Nacionalidad Actual";
            this.NacionalACT.Name = "NacionalACT";
            // 
            // Sexo
            // 
            this.Sexo.HeaderText = "Sexo";
            this.Sexo.Name = "Sexo";
            // 
            // estciv
            // 
            this.estciv.HeaderText = "Estado Civil";
            this.estciv.Name = "estciv";
            // 
            // apell3
            // 
            this.apell3.HeaderText = "Apellido del menor";
            this.apell3.Name = "apell3";
            // 
            // nomb2
            // 
            this.nomb2.HeaderText = "Nombre del menor";
            this.nomb2.Name = "nomb2";
            // 
            // direcmen
            // 
            this.direcmen.HeaderText = "Direccion del menor";
            this.direcmen.Name = "direcmen";
            // 
            // nacionPersoAcargo
            // 
            this.nacionPersoAcargo.HeaderText = "Nacionalidad de la persona que ejerce ";
            this.nacionPersoAcargo.Name = "nacionPersoAcargo";
            // 
            // Numdocmentonacio
            // 
            this.Numdocmentonacio.HeaderText = "Numero del documento nacional de identidad";
            this.Numdocmentonacio.Name = "Numdocmentonacio";
            // 
            // Tipodedocviaje
            // 
            this.Tipodedocviaje.HeaderText = "Tipo de ducmento  de viaje";
            this.Tipodedocviaje.Name = "Tipodedocviaje";
            // 
            // Numdocviaje
            // 
            this.Numdocviaje.HeaderText = "Numero del documento de viaje";
            this.Numdocviaje.Name = "Numdocviaje";
            // 
            // fechaexped
            // 
            this.fechaexped.HeaderText = "Fecha de expedicion";
            this.fechaexped.Name = "fechaexped";
            // 
            // Validhast
            // 
            this.Validhast.HeaderText = "Valido hasta";
            this.Validhast.Name = "Validhast";
            // 
            // Expedidopor
            // 
            this.Expedidopor.HeaderText = "Expedido por";
            this.Expedidopor.Name = "Expedidopor";
            // 
            // Domipos
            // 
            this.Domipos.HeaderText = "Domicilio postal";
            this.Domipos.Name = "Domipos";
            // 
            // Correo
            // 
            this.Correo.HeaderText = "Correo";
            this.Correo.Name = "Correo";
            // 
            // residentdeunpaisdistintdelactual
            // 
            this.residentdeunpaisdistintdelactual.HeaderText = "Residente de un país distinto al actual";
            this.residentdeunpaisdistintdelactual.Name = "residentdeunpaisdistintdelactual";
            // 
            // numtelefono
            // 
            this.numtelefono.HeaderText = "Numero de telefono";
            this.numtelefono.Name = "numtelefono";
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(1230, 817);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 16;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(1398, 817);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(75, 23);
            this.btnSalir.TabIndex = 17;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1311, 817);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "EDITAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnNuevo
            // 
            this.btnNuevo.Location = new System.Drawing.Point(1230, 847);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(75, 23);
            this.btnNuevo.TabIndex = 19;
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.UseVisualStyleBackColor = true;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // btnbuscar
            // 
            this.btnbuscar.Location = new System.Drawing.Point(229, 26);
            this.btnbuscar.Name = "btnbuscar";
            this.btnbuscar.Size = new System.Drawing.Size(75, 23);
            this.btnbuscar.TabIndex = 20;
            this.btnbuscar.Text = "Buscar";
            this.btnbuscar.UseVisualStyleBackColor = true;
            this.btnbuscar.Click += new System.EventHandler(this.btnbuscar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(66, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(144, 117);
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnbuscar);
            this.Controls.Add(this.btnNuevo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.dgvdato);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdato)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtapell1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtpaisNac;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtLugNaci;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtFecha1;
        private System.Windows.Forms.TextBox txtaño;
        private System.Windows.Forms.TextBox txtMes;
        private System.Windows.Forms.TextBox txtDia;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtnomb1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtapell2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtdirec2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtnombre2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtApellido3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox cboestadocivil;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton btmujer;
        private System.Windows.Forms.RadioButton btvaron;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox TxtNumTel1;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox txtRecide;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.TextBox TxtdomPost;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txtExpedPor;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txtValidHast;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txtFechaEXpide;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txtNumDocViaje;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox txtotros;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RadioButton rbpasofic;
        private System.Windows.Forms.RadioButton rbpasotros;
        private System.Windows.Forms.RadioButton rbpasespec;
        private System.Windows.Forms.RadioButton rbpasdiplo;
        private System.Windows.Forms.RadioButton rbpasServi;
        private System.Windows.Forms.RadioButton rbpasordi;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtnumDocnaciosiProced;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtNacPersoEjerce;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtNacionACT;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgvdato;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn apell1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombre1;
        private System.Windows.Forms.DataGridViewTextBoxColumn FechaNaimi;
        private System.Windows.Forms.DataGridViewTextBoxColumn lugnaci;
        private System.Windows.Forms.DataGridViewTextBoxColumn paisNci;
        private System.Windows.Forms.DataGridViewTextBoxColumn NacionalACT;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sexo;
        private System.Windows.Forms.DataGridViewTextBoxColumn estciv;
        private System.Windows.Forms.DataGridViewTextBoxColumn apell3;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomb2;
        private System.Windows.Forms.DataGridViewTextBoxColumn direcmen;
        private System.Windows.Forms.DataGridViewTextBoxColumn nacionPersoAcargo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numdocmentonacio;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tipodedocviaje;
        private System.Windows.Forms.DataGridViewTextBoxColumn Numdocviaje;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaexped;
        private System.Windows.Forms.DataGridViewTextBoxColumn Validhast;
        private System.Windows.Forms.DataGridViewTextBoxColumn Expedidopor;
        private System.Windows.Forms.DataGridViewTextBoxColumn Domipos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Correo;
        private System.Windows.Forms.DataGridViewTextBoxColumn residentdeunpaisdistintdelactual;
        private System.Windows.Forms.DataGridViewTextBoxColumn numtelefono;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnbuscar;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

