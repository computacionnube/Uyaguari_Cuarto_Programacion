﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Cyber_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Pc1
        int h1, m1, s1;
        int dd, ss, hh, mm ;
        
        private void TimeInicio_Tick(object sender, EventArgs e)
        {
            //aumentar

            
            
            //Decrecer
            s1--;
            if (s1<=0)
            {
                if (m1>0)
                {
                    m1--;
                    s1 = 59;
                }
            }
            if (m1==0)
            {
                if (h1>0)
                {
                    h1--;
                    m1 = 59;
                }
            }
            
            Nudhoras.Value = Convert.ToDecimal(h1);
            NudMinutos.Value = Convert.ToDecimal(m1);
            Nudsegundos.Value = Convert.ToDecimal(s1);
           
        }

        private void btnPc1_Click(object sender, EventArgs e)
        {
            TimePC1.Start();
            txtEstado1.Text = "Ocupado";
            h1 = Convert.ToInt32(Nudhoras.Value);
            m1 = Convert.ToInt32(NudMinutos.Value);
            s1 = Convert.ToInt32(Nudsegundos.Value);
          
            TimeInicio.Start();
        }

        private void TimePC1_Tick(object sender, EventArgs e)
        {
            string ht, mt, st;
            dd++;
            if (dd == 0)
            {
                dd = 0;
                ss++;
                if (ss == 60)
                {
                    mm++;
                    ss = 0;
                }
                if (mm == 60)
                {
                    hh++;
                }
            }
            if (hh < 10)
            {
                ht = "0" + Convert.ToString(hh);
            }
            else
            {
                ht = Convert.ToString(hh);
            }
            if (mm < 10)
            {
                mt = "0" + Convert.ToString(mm);
            }
            else
            {
                mt = Convert.ToString(mm);
            }
            if (ss < 10)
            {
                st = "0" + Convert.ToString(ss);
            }
            else
            {
                st = Convert.ToString(ss);

            }
            txtTimeUs1.Text = ht + ":" + mt + ":" + st;
            lblUso1.Text = ht + ":" + mt + ":" + st;
        }
    }
}
