﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FORMULARIO
{
    public partial class frmEjer1 : Form
    {
        public frmEjer1()
        {
            InitializeComponent();
        }
       
        private void btnCierra1_Click(object sender, EventArgs e)
        {
            Form1.ActiveForm.Show();
            this.Close();
        }
        //variables para generar primo
        int lim;
        bool control = true;
        int prim = 1;
        private void Primos()
        {
            if (txtLim.Text == "")
            {
                lstPrim.Items.Clear();
            }
            else
            {
                lim = Convert.ToInt32(txtLim.Text);
                for (int i = 0; i < lim; i++)
                {
                    control = false;
                    while (control == false)
                    {
                        int divi = 2;
                        while (prim >= divi && prim % divi != 0)
                        {
                            divi++;
                        }
                        if (prim <= divi)
                        {
                            control = true;
                        }
                        else
                        {
                            prim = prim + 1;
                        }
                    }
                    lstPrim.Items.Add(prim);
                    prim = prim + 1;


                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Primos();

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            lstPrim.Items.Clear();
            txtLim.Text = " ";
        }
    }
}
