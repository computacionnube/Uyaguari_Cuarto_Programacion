﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FORMULARIO
{
    public partial class frmEjer4 : Form
    {
        frmNuevo objNuevo = new frmNuevo();
        public frmEjer4()
        {
            InitializeComponent();
        }

        private void btnPresenta_Click(object sender, EventArgs e)
        {
            objNuevo.Show();//
        }

        private void btnRepito_Click(object sender, EventArgs e)
        {
            objNuevo.Visible = true;//
        }

        private void btnCierra4_Click(object sender, EventArgs e)
        {
            this.Close();//
        }
    }
}
