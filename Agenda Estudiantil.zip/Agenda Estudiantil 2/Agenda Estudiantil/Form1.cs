﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Agenda_Estudiantil
{
     
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Limpiar();
        }
        int pos;
        int i = 1;
 
        private void Limpiar()
        {
            textdirec.Text = "";
            textced.Text = "";
            textedad.Text = "";
            textestadoC.Text = "";
            textmail.Text = "";
            texttel.Text="";
            textNombre.Text = "";
            textapeli.Text = "";
        }
       
        private void butAdd_Click(object sender, EventArgs e)
        {
            string  cedula, apellido, nombre, telefono, unidadeducativa, estadocivi, edad, mail,direccion;
            cedula = textced.Text;
            apellido = textapeli.Text;
            nombre = textNombre.Text;
            telefono = texttel.Text;
            unidadeducativa = textunidda.Text;
            estadocivi = textestadoC.Text;
            edad = textedad.Text;
            mail = textmail.Text;
            direccion = textdirec.Text;
            Limpiar();
          
            if (cBxnacionalida.SelectedIndex==0)
            {
                if (checkF.Checked == true)
                {
                
                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkF.Text, edad, estadocivi,combosangre.Text);
                   
                }

                if (checkM.Checked == true)
                {
                    
                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkM.Text, edad, estadocivi,combosangre.Text);
                }
         
     
            }
            if (cBxnacionalida.SelectedIndex==1)
            {
                if (checkF.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkF.Text, edad, estadocivi, combosangre.Text);
                }

                if (checkM.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkM.Text, edad, estadocivi, combosangre.Text);
                }
            }
            if (cBxnacionalida.SelectedIndex == 2)
            {
                if (checkF.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkF.Text, edad, estadocivi, combosangre.Text);
                }

                if (checkM.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkM.Text, edad, estadocivi, combosangre.Text);
                }
            }
            if (cBxnacionalida.SelectedIndex == 3)
            {
                if (checkF.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkF.Text, edad, estadocivi, combosangre.Text);
                }

                if (checkM.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkM.Text, edad, estadocivi, combosangre.Text);
                }
            }
            if (cBxnacionalida.SelectedIndex == 4)
            {
                if (checkF.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkF.Text, edad, estadocivi, combosangre.Text);
                }

                if (checkM.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkM.Text, edad, estadocivi, combosangre.Text);
                }
            }
            if (cBxnacionalida.SelectedIndex == 5)
            {
                if (checkF.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkF.Text, edad, estadocivi, combosangre.Text);
                }

                if (checkM.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkM.Text, edad, estadocivi, combosangre.Text);
                }
            }
            if (cBxnacionalida.SelectedIndex == 6)
            {
                if (checkF.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkF.Text, edad, estadocivi, combosangre.Text);
                }

                if (checkM.Checked == true)
                {

                    dataRegistro.Rows.Add(i, cBxnacionalida.Text, cedula, nombre, apellido, telefono, direccion, mail, cBxcarrera.Text, cBxCiclo.Text, checkM.Text, edad, estadocivi, combosangre.Text);
                }


            }
            
            MessageBox.Show("CAMPOS OBLIGATORIOS");
            
            
            i++;
           

            
        }

        private void dataRegistro_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pos = dataRegistro.CurrentRow.Index;
            if (cBxnacionalida.SelectedIndex==0)
            {
                cBxnacionalida.Text = dataRegistro[1, pos].Value.ToString();
            }
            if (cBxnacionalida.SelectedIndex == 1)
            {
                cBxnacionalida.Text = dataRegistro[1, pos].Value.ToString();
            }
            if (cBxnacionalida.SelectedIndex == 2)
            {
                cBxnacionalida.Text = dataRegistro[1, pos].Value.ToString();
            }
            if (cBxnacionalida.SelectedIndex == 3)
            {
                cBxnacionalida.Text = dataRegistro[1, pos].Value.ToString();
            }
            if (cBxnacionalida.SelectedIndex == 4)
            {
                cBxnacionalida.Text = dataRegistro[1, pos].Value.ToString();
            }
            if (cBxnacionalida.SelectedIndex == 5)
            {
                cBxnacionalida.Text = dataRegistro[1, pos].Value.ToString();
            }
            if (cBxnacionalida.SelectedIndex == 6)
            {
                cBxnacionalida.Text = dataRegistro[1, pos].Value.ToString();
            }
            textced.Text = dataRegistro[2, pos].Value.ToString();
            
            textNombre.Text = dataRegistro[3, pos].Value.ToString();
            textapeli.Text = dataRegistro[4, pos].Value.ToString();
            texttel.Text = dataRegistro[5, pos].Value.ToString();
            textdirec.Text = dataRegistro[6, pos].Value.ToString();
            textmail.Text = dataRegistro[7, pos].Value.ToString();
            cBxcarrera.Text = dataRegistro[8, pos].Value.ToString();
            cBxCiclo.Text=dataRegistro[9, pos].Value.ToString();
            if (checkM.Checked==true)
            {
                checkM.Text=dataRegistro[10, pos].Value.ToString();
            }
            if (checkF.Checked==true)
            {
                checkF.Text=dataRegistro[10, pos].Value.ToString();
            }
            textedad.Text = dataRegistro[11, pos].Value.ToString();
            textestadoC.Text = dataRegistro[12, pos].Value.ToString();
            combosangre.Text = dataRegistro[13, pos].Value.ToString();
            
            
            
        }

        private void butEdd_Click(object sender, EventArgs e)
        {
            
            if (cBxnacionalida.SelectedIndex==0)
            {
                dataRegistro[1, pos].Value = cBxnacionalida.Text;
            }
            if (cBxnacionalida.SelectedIndex == 1)
            {
                dataRegistro[1, pos].Value = cBxnacionalida.Text;
            }
            if (cBxnacionalida.SelectedIndex == 2)
            {
                dataRegistro[1, pos].Value = cBxnacionalida.Text;
            }
            if (cBxnacionalida.SelectedIndex == 3)
            {
                dataRegistro[1, pos].Value = cBxnacionalida.Text;
            }
            if (cBxnacionalida.SelectedIndex == 4)
            {
                dataRegistro[1, pos].Value = cBxnacionalida.Text;
            }
            if (cBxnacionalida.SelectedIndex == 5)
            {
                dataRegistro[1, pos].Value = cBxnacionalida.Text;
            }
            if (cBxnacionalida.SelectedIndex == 6)
            {
                dataRegistro[1, pos].Value = cBxnacionalida.Text;
            }
            dataRegistro[2, pos].Value = textced.Text;
            dataRegistro[3, pos].Value = textNombre.Text;
            dataRegistro[4, pos].Value = textapeli.Text;
            dataRegistro[5, pos].Value = texttel.Text;
            dataRegistro[6, pos].Value = textdirec.Text;
            dataRegistro[7, pos].Value = textmail.Text;
            dataRegistro[8, pos].Value = cBxcarrera.Text;
            dataRegistro[9, pos].Value = cBxCiclo.Text;
            if (checkF.Checked==true)
            {
                dataRegistro[10, pos].Value = checkF.Text; 
            }
            if (checkM.Checked==true)
            {
                dataRegistro[10, pos].Value = checkM.Text; 
            }
            dataRegistro[11, pos].Value = textedad.Text;
            dataRegistro[12, pos].Value = textestadoC.Text;
            dataRegistro[13, pos].Value = combosangre.Text;

        }

        private void butEliminar_Click(object sender, EventArgs e)
        {
            dataRegistro.Rows.RemoveAt(pos);
        }

        private void butnew_Click(object sender, EventArgs e)
        {
            Limpiar();
            cBxcarrera.Text = "";
            cBxCiclo.Text = "";
            cBxnacionalida.Text = "";
            grBGenero.Enabled = true;
            
            checkM.Enabled = true;
            checkF.Enabled = true;
        }

        private void textNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textced_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textapeli_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textdirec_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }


        private void textestadoC_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void texttel_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void textedad_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void checkM_MouseClick(object sender, MouseEventArgs e)
        {
            if (checkM.Enabled == true)
            {
                checkF.Enabled = false;
            }
            else
            {
                checkF.Enabled = true;
            }
            grBGenero.Enabled = false;
        }

        private void checkF_MouseClick(object sender, MouseEventArgs e)
        {
            if (checkF.Enabled == true)
            {
                checkM.Enabled = false;
            }
            else
            {
                checkM.Enabled = true;
            }
            grBGenero.Enabled = false;
        }

    }
}
