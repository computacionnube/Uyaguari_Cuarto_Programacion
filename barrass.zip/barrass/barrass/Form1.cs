﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace barrass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Reloj_Tick(object sender, EventArgs e)
        {

            progressBar1.Value = progressBar1.Value + 1;
            labprogre.Text = Convert.ToString(progressBar1.Value);
            if (progressBar1.Value==100)
            {
                Reloj.Stop();
                MessageBox.Show("Que no ves que ya llego al 100 grandisimo bobo");
                progressBar1.Value=0;
            }
        }

        private void butiniciar_Click(object sender, EventArgs e)
        {
            Reloj.Start();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bobo");
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (toolStripButton2.Checked==false)
            {
                toolStripButton2.Checked = true;
                MessageBox.Show("Presio");
            }
            else
            {
                toolStripButton2.Checked = false;
                MessageBox.Show("Presionado");

            }

        }

        private void txtes_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (letra==13)
            {
                if (txtes.Text == "activo") 
                {
                    toolStripButton3.Visible = true;
                }
            }
            
            
        }

        
      
    }
}
