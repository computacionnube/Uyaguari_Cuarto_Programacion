﻿namespace TabControl
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tcDato = new System.Windows.Forms.ToolStripMenuItem();
            this.iNICIOPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNGRESOAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.iNGRESOBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sALIRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsl1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsl2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsp1 = new System.Windows.Forms.ToolStripProgressBar();
            this.tsm1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsl4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tp1 = new System.Windows.Forms.TabPage();
            this.btnsalir = new System.Windows.Forms.Button();
            this.p1 = new System.Windows.Forms.Panel();
            this.btneditar = new System.Windows.Forms.Button();
            this.btnnuevo = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tp2 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btncancel = new System.Windows.Forms.Button();
            this.btnguarda = new System.Windows.Forms.Button();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txttelf = new System.Windows.Forms.TextBox();
            this.txtdir = new System.Windows.Forms.TextBox();
            this.txtnomb = new System.Windows.Forms.TextBox();
            this.txtced = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tp3 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnregreso = new System.Windows.Forms.Button();
            this.btnguardar1 = new System.Windows.Forms.Button();
            this.txttit = new System.Windows.Forms.TextBox();
            this.txtsup = new System.Windows.Forms.TextBox();
            this.txttitul = new System.Windows.Forms.TextBox();
            this.txtbachille = new System.Windows.Forms.TextBox();
            this.txtprim = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tp1.SuspendLayout();
            this.p1.SuspendLayout();
            this.tp2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tp3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tcDato,
            this.sALIRToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(492, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tcDato
            // 
            this.tcDato.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iNICIOPToolStripMenuItem,
            this.iNGRESOAToolStripMenuItem,
            this.toolStripSeparator1,
            this.iNGRESOBToolStripMenuItem});
            this.tcDato.Name = "tcDato";
            this.tcDato.Size = new System.Drawing.Size(51, 20);
            this.tcDato.Text = "DATO";
            // 
            // iNICIOPToolStripMenuItem
            // 
            this.iNICIOPToolStripMenuItem.Name = "iNICIOPToolStripMenuItem";
            this.iNICIOPToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.iNICIOPToolStripMenuItem.Text = "INICIO";
            // 
            // iNGRESOAToolStripMenuItem
            // 
            this.iNGRESOAToolStripMenuItem.Name = "iNGRESOAToolStripMenuItem";
            this.iNGRESOAToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.iNGRESOAToolStripMenuItem.Text = "INGRESO A";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(130, 6);
            // 
            // iNGRESOBToolStripMenuItem
            // 
            this.iNGRESOBToolStripMenuItem.Name = "iNGRESOBToolStripMenuItem";
            this.iNGRESOBToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.iNGRESOBToolStripMenuItem.Text = "INGRESO B";
            // 
            // sALIRToolStripMenuItem
            // 
            this.sALIRToolStripMenuItem.Name = "sALIRToolStripMenuItem";
            this.sALIRToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.sALIRToolStripMenuItem.Text = "SALIR";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripComboBox1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(492, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "toolStripButton2";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "toolStripButton3";
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 25);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.Transparent;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsl1,
            this.tsl2,
            this.tsp1,
            this.tsm1,
            this.tsl4});
            this.statusStrip1.Location = new System.Drawing.Point(0, 404);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(492, 25);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsl1
            // 
            this.tsl1.BackColor = System.Drawing.Color.Black;
            this.tsl1.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.tsl1.BorderStyle = System.Windows.Forms.Border3DStyle.Raised;
            this.tsl1.ForeColor = System.Drawing.Color.White;
            this.tsl1.Image = ((System.Drawing.Image)(resources.GetObject("tsl1.Image")));
            this.tsl1.ImageTransparentColor = System.Drawing.Color.White;
            this.tsl1.Name = "tsl1";
            this.tsl1.Size = new System.Drawing.Size(74, 20);
            this.tsl1.Text = "AGENDA";
            this.tsl1.Click += new System.EventHandler(this.tsl1_Click);
            // 
            // tsl2
            // 
            this.tsl2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tsl2.ForeColor = System.Drawing.Color.Black;
            this.tsl2.Image = ((System.Drawing.Image)(resources.GetObject("tsl2.Image")));
            this.tsl2.Name = "tsl2";
            this.tsl2.Size = new System.Drawing.Size(60, 20);
            this.tsl2.Text = "FECHA";
            // 
            // tsp1
            // 
            this.tsp1.Name = "tsp1";
            this.tsp1.Size = new System.Drawing.Size(100, 19);
            this.tsp1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            // 
            // tsm1
            // 
            this.tsm1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsm1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.tsm1.Image = ((System.Drawing.Image)(resources.GetObject("tsm1.Image")));
            this.tsm1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsm1.Name = "tsm1";
            this.tsm1.Size = new System.Drawing.Size(29, 23);
            this.tsm1.Text = "toolStripDropDownButton1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem1.Text = "NOMBRE";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem2.Text = "CARRERA";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(158, 22);
            this.toolStripMenuItem3.Text = "CUARTO CICLO";
            // 
            // tsl4
            // 
            this.tsl4.Name = "tsl4";
            this.tsl4.Size = new System.Drawing.Size(30, 20);
            this.tsl4.Text = "hola";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tp1);
            this.tabControl1.Controls.Add(this.tp2);
            this.tabControl1.Controls.Add(this.tp3);
            this.tabControl1.Location = new System.Drawing.Point(0, 45);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(491, 314);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tp1
            // 
            this.tp1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tp1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tp1.Controls.Add(this.btnsalir);
            this.tp1.Controls.Add(this.p1);
            this.tp1.Controls.Add(this.listBox1);
            this.tp1.Location = new System.Drawing.Point(4, 22);
            this.tp1.Name = "tp1";
            this.tp1.Padding = new System.Windows.Forms.Padding(3);
            this.tp1.Size = new System.Drawing.Size(483, 288);
            this.tp1.TabIndex = 0;
            this.tp1.Text = "INICIO";
            // 
            // btnsalir
            // 
            this.btnsalir.Location = new System.Drawing.Point(302, 230);
            this.btnsalir.Name = "btnsalir";
            this.btnsalir.Size = new System.Drawing.Size(75, 23);
            this.btnsalir.TabIndex = 2;
            this.btnsalir.Text = "salir";
            this.btnsalir.UseVisualStyleBackColor = true;
            // 
            // p1
            // 
            this.p1.BackColor = System.Drawing.Color.Transparent;
            this.p1.Controls.Add(this.btneditar);
            this.p1.Controls.Add(this.btnnuevo);
            this.p1.Location = new System.Drawing.Point(279, 47);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(120, 160);
            this.p1.TabIndex = 1;
            // 
            // btneditar
            // 
            this.btneditar.Location = new System.Drawing.Point(23, 72);
            this.btneditar.Name = "btneditar";
            this.btneditar.Size = new System.Drawing.Size(75, 23);
            this.btneditar.TabIndex = 1;
            this.btneditar.Text = "editar";
            this.btneditar.UseVisualStyleBackColor = true;
            // 
            // btnnuevo
            // 
            this.btnnuevo.Location = new System.Drawing.Point(23, 42);
            this.btnnuevo.Name = "btnnuevo";
            this.btnnuevo.Size = new System.Drawing.Size(75, 23);
            this.btnnuevo.TabIndex = 0;
            this.btnnuevo.Text = "nuevo";
            this.btnnuevo.UseVisualStyleBackColor = true;
            this.btnnuevo.Click += new System.EventHandler(this.btnnuevo_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(7, 21);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(266, 186);
            this.listBox1.TabIndex = 0;
            // 
            // tp2
            // 
            this.tp2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tp2.Controls.Add(this.panel1);
            this.tp2.Location = new System.Drawing.Point(4, 22);
            this.tp2.Name = "tp2";
            this.tp2.Padding = new System.Windows.Forms.Padding(3);
            this.tp2.Size = new System.Drawing.Size(483, 288);
            this.tp2.TabIndex = 1;
            this.tp2.Text = "INGRESO A";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.btncancel);
            this.panel1.Controls.Add(this.btnguarda);
            this.panel1.Controls.Add(this.txtemail);
            this.panel1.Controls.Add(this.txttelf);
            this.panel1.Controls.Add(this.txtdir);
            this.panel1.Controls.Add(this.txtnomb);
            this.panel1.Controls.Add(this.txtced);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(30, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(404, 215);
            this.panel1.TabIndex = 4;
            // 
            // btncancel
            // 
            this.btncancel.Location = new System.Drawing.Point(262, 147);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 23);
            this.btncancel.TabIndex = 11;
            this.btncancel.Text = "CANCELAR";
            this.btncancel.UseVisualStyleBackColor = true;
            // 
            // btnguarda
            // 
            this.btnguarda.Location = new System.Drawing.Point(262, 108);
            this.btnguarda.Name = "btnguarda";
            this.btnguarda.Size = new System.Drawing.Size(75, 23);
            this.btnguarda.TabIndex = 10;
            this.btnguarda.Text = "GUARDAR";
            this.btnguarda.UseVisualStyleBackColor = true;
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(108, 166);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(100, 20);
            this.txtemail.TabIndex = 9;
            // 
            // txttelf
            // 
            this.txttelf.Location = new System.Drawing.Point(108, 123);
            this.txttelf.Name = "txttelf";
            this.txttelf.Size = new System.Drawing.Size(100, 20);
            this.txttelf.TabIndex = 8;
            // 
            // txtdir
            // 
            this.txtdir.Location = new System.Drawing.Point(108, 91);
            this.txtdir.Name = "txtdir";
            this.txtdir.Size = new System.Drawing.Size(100, 20);
            this.txtdir.TabIndex = 7;
            // 
            // txtnomb
            // 
            this.txtnomb.Location = new System.Drawing.Point(108, 58);
            this.txtnomb.Name = "txtnomb";
            this.txtnomb.Size = new System.Drawing.Size(100, 20);
            this.txtnomb.TabIndex = 6;
            // 
            // txtced
            // 
            this.txtced.Location = new System.Drawing.Point(108, 21);
            this.txtced.Name = "txtced";
            this.txtced.Size = new System.Drawing.Size(100, 20);
            this.txtced.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "EMAIL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "TELEFONO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "DIRECCION";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "NOMOBRES";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "CEDULA";
            // 
            // tp3
            // 
            this.tp3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tp3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tp3.Controls.Add(this.panel2);
            this.tp3.Location = new System.Drawing.Point(4, 22);
            this.tp3.Name = "tp3";
            this.tp3.Padding = new System.Windows.Forms.Padding(3);
            this.tp3.Size = new System.Drawing.Size(483, 288);
            this.tp3.TabIndex = 2;
            this.tp3.Text = "INGRESO B";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnregreso);
            this.panel2.Controls.Add(this.btnguardar1);
            this.panel2.Controls.Add(this.txttit);
            this.panel2.Controls.Add(this.txtsup);
            this.panel2.Controls.Add(this.txttitul);
            this.panel2.Controls.Add(this.txtbachille);
            this.panel2.Controls.Add(this.txtprim);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(45, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(428, 204);
            this.panel2.TabIndex = 0;
            // 
            // btnregreso
            // 
            this.btnregreso.Location = new System.Drawing.Point(350, 164);
            this.btnregreso.Name = "btnregreso";
            this.btnregreso.Size = new System.Drawing.Size(75, 23);
            this.btnregreso.TabIndex = 11;
            this.btnregreso.Text = "REGRESO";
            this.btnregreso.UseVisualStyleBackColor = true;
            // 
            // btnguardar1
            // 
            this.btnguardar1.Location = new System.Drawing.Point(350, 119);
            this.btnguardar1.Name = "btnguardar1";
            this.btnguardar1.Size = new System.Drawing.Size(75, 23);
            this.btnguardar1.TabIndex = 10;
            this.btnguardar1.Text = "GUARDAR";
            this.btnguardar1.UseVisualStyleBackColor = true;
            // 
            // txttit
            // 
            this.txttit.Location = new System.Drawing.Point(165, 157);
            this.txttit.Name = "txttit";
            this.txttit.Size = new System.Drawing.Size(161, 20);
            this.txttit.TabIndex = 9;
            // 
            // txtsup
            // 
            this.txtsup.Location = new System.Drawing.Point(165, 122);
            this.txtsup.Name = "txtsup";
            this.txtsup.Size = new System.Drawing.Size(161, 20);
            this.txtsup.TabIndex = 8;
            // 
            // txttitul
            // 
            this.txttitul.Location = new System.Drawing.Point(165, 92);
            this.txttitul.Name = "txttitul";
            this.txttitul.Size = new System.Drawing.Size(161, 20);
            this.txttitul.TabIndex = 7;
            // 
            // txtbachille
            // 
            this.txtbachille.Location = new System.Drawing.Point(165, 57);
            this.txtbachille.Name = "txtbachille";
            this.txtbachille.Size = new System.Drawing.Size(161, 20);
            this.txtbachille.TabIndex = 6;
            // 
            // txtprim
            // 
            this.txtprim.Location = new System.Drawing.Point(165, 31);
            this.txtprim.Name = "txtprim";
            this.txtprim.Size = new System.Drawing.Size(161, 20);
            this.txtprim.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(49, 164);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "TITULO:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(49, 129);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(63, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "SUPERIOR";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(49, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "TITULO";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(49, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "BACHILLERATO";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(49, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "PRIMARIA";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 429);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tp1.ResumeLayout(false);
            this.p1.ResumeLayout(false);
            this.tp2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tp3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tcDato;
        private System.Windows.Forms.ToolStripMenuItem iNICIOPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNGRESOAToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem iNGRESOBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sALIRToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsl1;
        private System.Windows.Forms.ToolStripStatusLabel tsl2;
        private System.Windows.Forms.ToolStripProgressBar tsp1;
        private System.Windows.Forms.ToolStripDropDownButton tsm1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripStatusLabel tsl4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tp1;
        private System.Windows.Forms.TabPage tp2;
        private System.Windows.Forms.TabPage tp3;
        private System.Windows.Forms.Button btnsalir;
        private System.Windows.Forms.Panel p1;
        private System.Windows.Forms.Button btneditar;
        private System.Windows.Forms.Button btnnuevo;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Button btnguarda;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txttelf;
        private System.Windows.Forms.TextBox txtdir;
        private System.Windows.Forms.TextBox txtnomb;
        private System.Windows.Forms.TextBox txtced;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnregreso;
        private System.Windows.Forms.Button btnguardar1;
        private System.Windows.Forms.TextBox txttit;
        private System.Windows.Forms.TextBox txtsup;
        private System.Windows.Forms.TextBox txttitul;
        private System.Windows.Forms.TextBox txtbachille;
        private System.Windows.Forms.TextBox txtprim;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
    }
}

