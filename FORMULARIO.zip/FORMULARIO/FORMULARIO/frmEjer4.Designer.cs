﻿namespace FORMULARIO
{
    partial class frmEjer4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCierra4 = new System.Windows.Forms.Button();
            this.btnRepito = new System.Windows.Forms.Button();
            this.btnPresenta = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCierra4
            // 
            this.btnCierra4.Location = new System.Drawing.Point(197, 227);
            this.btnCierra4.Name = "btnCierra4";
            this.btnCierra4.Size = new System.Drawing.Size(75, 23);
            this.btnCierra4.TabIndex = 3;
            this.btnCierra4.Text = "CERRAR";
            this.btnCierra4.UseVisualStyleBackColor = true;
            this.btnCierra4.Click += new System.EventHandler(this.btnCierra4_Click);
            // 
            // btnRepito
            // 
            this.btnRepito.Location = new System.Drawing.Point(12, 96);
            this.btnRepito.Name = "btnRepito";
            this.btnRepito.Size = new System.Drawing.Size(75, 23);
            this.btnRepito.TabIndex = 4;
            this.btnRepito.Text = "REPITO";
            this.btnRepito.UseVisualStyleBackColor = true;
            this.btnRepito.Click += new System.EventHandler(this.btnRepito_Click);
            // 
            // btnPresenta
            // 
            this.btnPresenta.Location = new System.Drawing.Point(12, 37);
            this.btnPresenta.Name = "btnPresenta";
            this.btnPresenta.Size = new System.Drawing.Size(75, 23);
            this.btnPresenta.TabIndex = 5;
            this.btnPresenta.Text = "PRESENTA";
            this.btnPresenta.UseVisualStyleBackColor = true;
            this.btnPresenta.Click += new System.EventHandler(this.btnPresenta_Click);
            // 
            // frmEjer4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btnPresenta);
            this.Controls.Add(this.btnRepito);
            this.Controls.Add(this.btnCierra4);
            this.Name = "frmEjer4";
            this.Text = "frmEjer4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCierra4;
        private System.Windows.Forms.Button btnRepito;
        private System.Windows.Forms.Button btnPresenta;
    }
}