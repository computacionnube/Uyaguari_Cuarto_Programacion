﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FORMULARIO
{
    public partial class frmEjer3 : Form
    {
        public frmEjer3()
        {
            InitializeComponent();
        }

        private void btnCierra3_Click(object sender, EventArgs e)
        {
            frmEjer3.ActiveForm.Close();//activeform es para mostrar la ventana oculta 
        }
        Random aleatorio = new Random();
        int lim;
        private void generarA()
        {
            lim = Convert.ToInt32(textBox1.Text);
            for (int i = 0; i < lim; i++)
            {
                aleatorio.Next(1, 50);
                lstA.Items.Add(i);
            }
           
        }
        private void generarB()
        {
            lim = Convert.ToInt32(textBox1.Text);
            for (int i = 0; i < lim; i++)
            {
                aleatorio.Next(1, 50);
                lstB.Items.Add(i);
            }
 
        }

        private void btnlstA_Click(object sender, EventArgs e)
        {
            
            generarA();
        }
           
    }
}
