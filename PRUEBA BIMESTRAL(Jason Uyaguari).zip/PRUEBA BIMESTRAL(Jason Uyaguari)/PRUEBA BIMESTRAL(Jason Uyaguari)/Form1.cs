﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PRUEBA_BIMESTRAL_Jason_Uyaguari_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // declarar variables
        int pos;
        int i = 1;
        string sexo,tipodoc;
        private void limpiar()
        {
          txtapell1.Text="";
           txtapell2.Text= "";
            txtnomb1.Text= "";
            txtDia.Text = "";
            txtMes.Text = "";
            txtaño.Text = "";
            txtFecha1.Text = "";
            txtLugNaci.Text = "";
            txtpaisNac.Text = "";
            txtNacionACT.Text = "";
            txtApellido3.Text = "";
            txtnombre2.Text = "";
            txtdirec2.Text = "";
            txtNacPersoEjerce.Text = "";
            txtnumDocnaciosiProced.Text = "";
            txtNumDocViaje.Text = "";
            txtFechaEXpide.Text = "";
            txtValidHast.Text = "";
            txtExpedPor.Text = "";
            TxtdomPost.Text = "";
            txtCorreo.Text = "";
            txtRecide.Text = "";
            TxtNumTel1.Text = "";
            sexo = "";
            tipodoc = "";
            cboestadocivil.Text= "";
            dgvdato.Rows.Clear();
            i = 1;
 
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string apelli1, apell2, nomb1, lugnaci, paisnaci, nacionact,  apell3, nomb2, direc, nacionpatriapos, numdocidenti,  numdocviaj, fechaexpe, validohast, expedidopo, dompos, correo, residenpaisdisti, numtelf;

            if (txtapell1.Text == txtapell2.Text)
            {

                apelli1 = txtapell1.Text;
                apell2 = txtapell2.Text;
                nomb1 = txtnomb1.Text;
                string dia, mes, año, fecha;
                dia = txtDia.Text;
                mes = txtMes.Text;
                año = txtaño.Text;
                fecha = dia + "/" + mes + "/" + año;
                txtFecha1.Text = fecha;
                lugnaci = txtLugNaci.Text;
                paisnaci = txtpaisNac.Text;
                nacionact = txtNacionACT.Text;
                apell3 = txtApellido3.Text;
                nomb2 = txtnombre2.Text;
                direc = txtdirec2.Text;
                nacionpatriapos = txtNacPersoEjerce.Text;
                numdocidenti = txtnumDocnaciosiProced.Text;
                numdocviaj = txtNumDocViaje.Text;
                fechaexpe = txtFechaEXpide.Text;
                validohast = txtValidHast.Text;
                expedidopo = txtExpedPor.Text;
                dompos = TxtdomPost.Text;
                correo = txtCorreo.Text;
                residenpaisdisti = txtRecide.Text;
                numtelf = TxtNumTel1.Text;
                sexo = "";
                tipodoc = "";
                if (btvaron.Checked == true)
                {
                    sexo += btvaron.Text;
                }
                if (btmujer.Checked == true)
                {
                    sexo += btvaron.Text;
                }
                if (rbpasordi.Checked == true)
                {
                    tipodoc += rbpasordi.Text;
                }
                if (rbpasdiplo.Checked == true)
                {
                    tipodoc += rbpasdiplo.Text;
                }
                if (rbpasServi.Checked == true)
                {
                    tipodoc += rbpasServi.Text;
                }
                if (rbpasofic.Checked == true)
                {
                    tipodoc += rbpasofic.Text;
                }
                if (rbpasespec.Checked == true)
                {
                    tipodoc += rbpasespec.Text;
                }
                if (rbpasotros.Checked == true)
                {
                    tipodoc += txtotros.Text;
                }
                dgvdato.Rows.Add(i, apelli1, nomb1, fecha, lugnaci, paisnaci, nacionact, sexo, cboestadocivil.Text, apell3, nomb2, direc, nacionpatriapos, numdocidenti, tipodoc, numdocviaj, fechaexpe, validohast, expedidopo, dompos, correo,residenpaisdisti, numtelf);
                i++;
                limpiar();

            }
            else
            {
                MessageBox.Show("ERROR");
                limpiar();
                dgvdato.Rows.Clear();
                
            }
            
           
            


        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvdato_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
            pos = dgvdato.CurrentRow.Index;

            
            txtapell1.Text = dgvdato[1, pos].Value.ToString();

            txtnomb1.Text = dgvdato[2, pos].Value.ToString();

            txtFecha1.Text = dgvdato[3, pos].Value.ToString();
            txtLugNaci.Text = dgvdato[4, pos].Value.ToString();
            txtpaisNac.Text = dgvdato[5, pos].Value.ToString();
            txtNacionACT.Text = dgvdato[6, pos].Value.ToString();
            txtApellido3.Text = dgvdato[7, pos].Value.ToString();
            txtnombre2.Text = dgvdato[9, pos].Value.ToString();
            txtdirec2.Text = dgvdato[10, pos].Value.ToString();
            txtNacPersoEjerce.Text = dgvdato[11, pos].Value.ToString();
            txtnumDocnaciosiProced.Text = dgvdato[12, pos].Value.ToString();
            txtNumDocViaje.Text = dgvdato[13, pos].Value.ToString();
            txtFechaEXpide.Text = dgvdato[14, pos].Value.ToString();
            txtValidHast.Text = dgvdato[15, pos].Value.ToString();
            txtExpedPor.Text = dgvdato[16, pos].Value.ToString();
            TxtdomPost.Text = dgvdato[17, pos].Value.ToString();
            txtCorreo.Text = dgvdato[18, pos].Value.ToString();
            txtRecide.Text = dgvdato[19, pos].Value.ToString();
            TxtNumTel1.Text = dgvdato[20, pos].Value.ToString();

            if (btvaron.Checked == true)
            {
                btvaron.Text = dgvdato[7, pos].Value.ToString(); 
            }
            if (btmujer.Checked == true)
            {
                btvaron.Text=dgvdato[7, pos].Value.ToString();
            }
            if (rbpasordi.Checked == true)
            {
                rbpasordi.Text = dgvdato[11, pos].Value.ToString(); 
            }
            if (rbpasdiplo.Checked == true)
            {
                rbpasdiplo.Text = dgvdato[11, pos].Value.ToString(); 
            }
            if (rbpasServi.Checked == true)
            {
                rbpasServi.Text = dgvdato[11, pos].Value.ToString(); 
            }
            if (rbpasofic.Checked == true)
            {
                rbpasofic.Text = dgvdato[11, pos].Value.ToString(); ;
            }
            if (rbpasespec.Checked == true)
            {
                rbpasespec.Text = dgvdato[11, pos].Value.ToString(); ;
            }
            if (rbpasotros.Checked == true)
            {
                txtotros.Text = dgvdato[11, pos].Value.ToString(); ;
            }
            if (cboestadocivil.SelectedIndex == 0)
            {
                cboestadocivil.Text = dgvdato[8, pos].Value.ToString();
            }
            if (cboestadocivil.SelectedIndex == 1)
            {
                cboestadocivil.Text = dgvdato[8, pos].Value.ToString();
            }
            if (cboestadocivil.SelectedIndex == 2)
            {
                cboestadocivil.Text = dgvdato[8, pos].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            dgvdato[1, pos].Value = txtapell1.Text;
             dgvdato[2, pos].Value=txtnomb1.Text ;

             dgvdato[3, pos].Value=txtFecha1.Text ;
             dgvdato[4, pos].Value=txtLugNaci.Text ;
             dgvdato[5, pos].Value=txtpaisNac.Text ;
           dgvdato[6, pos].Value=txtpaisNac.Text ;
            dgvdato[7, pos].Value=txtApellido3.Text ;
            dgvdato[9, pos].Value= txtnombre2.Text ;
            dgvdato[10, pos].Value=txtdirec2.Text ;
           dgvdato[11, pos].Value= txtNacPersoEjerce.Text ;
             dgvdato[12, pos].Value=txtnumDocnaciosiProced.Text ;
             dgvdato[13, pos].Value=txtNumDocViaje.Text ;
            dgvdato[14, pos].Value =txtFechaEXpide.Text ;
            dgvdato[15, pos].Value= txtValidHast.Text ;
            dgvdato[16, pos].Value= txtExpedPor.Text ;
            dgvdato[17, pos].Value=TxtdomPost.Text ;
             dgvdato[18, pos].Value=txtCorreo.Text ;
             dgvdato[19, pos].Value = txtRecide.Text;
            dgvdato[20, pos].Value= TxtNumTel1.Text ;

            if (btvaron.Checked == true)
            {
                dgvdato[7, pos].Value= btvaron.Text ;
            }
            if (btmujer.Checked == true)
            {
               dgvdato[7, pos].Value= btvaron.Text ;
            }
            if (rbpasordi.Checked == true)
            {
                dgvdato[11, pos].Value=rbpasordi.Text  ;
            }
            if (rbpasdiplo.Checked == true)
            {
                 dgvdato[11, pos].Value =rbpasdiplo.Text ;
            }
            if (rbpasServi.Checked == true)
            {
                dgvdato[11, pos].Value = rbpasServi.Text ;
            }
            if (rbpasofic.Checked == true)
            {
               dgvdato[11, pos].Value= rbpasServi.Text  ;
            }
            if (rbpasespec.Checked == true)
            {
                dgvdato[11, pos].Value = rbpasespec.Text ;
            }
            if (rbpasotros.Checked == true)
            {
                 dgvdato[11, pos].Value=txtotros.Text  ;
            }
            if (cboestadocivil.SelectedIndex == 0)
            {
                dgvdato[8, pos].Value = cboestadocivil.Text;
            }
            if (cboestadocivil.SelectedIndex == 1)
            {
                 dgvdato[8, pos].Value=cboestadocivil.Text ;
            }
            if (cboestadocivil.SelectedIndex == 2)
            {
                 dgvdato[8, pos].Value=cboestadocivil.Text ;
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            limpiar();
            dgvdato.Rows.Clear();
        }

        private void rbpasotros_CheckedChanged(object sender, EventArgs e)
        {
            if (rbpasotros.Checked == true)
            {
                txtotros.Enabled =true;
            }
        }

        private void rbpasordi_CheckedChanged(object sender, EventArgs e)
        {
            if (rbpasordi.Checked == true)
            {
                txtotros.Enabled = false;
            }
        }

        private void rbpasdiplo_CheckedChanged(object sender, EventArgs e)
        {
            if (rbpasdiplo.Checked == true)
            {
                txtotros.Enabled = false;
            }
        }

        private void rbpasServi_CheckedChanged(object sender, EventArgs e)
        {
            if (rbpasServi.Checked == true)
            {
                txtotros.Enabled = false;
            }
        }

        private void rbpasofic_CheckedChanged(object sender, EventArgs e)
        {
            if (rbpasofic.Checked == true)
            {
                txtotros.Enabled = false;
            }
        }

        private void rbpasespec_CheckedChanged(object sender, EventArgs e)
        {
            if (rbpasespec.Checked == true)
            {
                txtotros.Enabled = false;
            }
        }

        private void btnbuscar_Click(object sender, EventArgs e)
        {
            OpenFileDialog Imagen = new OpenFileDialog();
            Imagen.InitialDirectory = "C:\\";
            Imagen.Filter = "Archivos de imagen (*.jpg)(jpeg)|*.jpg;*.jpeg|PNG(*.png)|*.png|GIF(*.gif)|*.gif";
            if (Imagen.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = Imagen.FileName;
                pictureBox2.ImageLocation = Imagen.FileName;

            }
            else
            {
                MessageBox.Show(" Ninguna imagen seleccionada", "Mensaje", MessageBoxButtons.OK);
            }
            
            
        }

        private void txtapell1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtapell2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

       

        private void txtDia_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtnomb1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtMes_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtaño_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }
    }
}
