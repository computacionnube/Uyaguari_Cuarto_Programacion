﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TabControl
{
    struct agenda 
    {
        string cedula, nombre, direccion, telefono, correo;
        public agenda(string ced,string nom,string dir,string tel,string cor)
        {
            cedula = ced;
            nombre = nom;
            direccion = dir;
            telefono = tel;
            correo = cor;
        }
        //cedula
        public void setced(string ced) {cedula = ced; }
        public string getced () { return cedula;  }
        //nombre
        public void setnom(string nom) {nombre = nom; }
        public string getnomb() { return nombre; }
        //direccion
        public void setdire(string dir) { direccion = dir; }
        public string getdire() { return direccion; }
        //telefono
        public void settel(string tel) { telefono = tel; }
        public string gettelf() { return telefono; }
        //correo
        public void setcorr(string corr) { correo = corr; }
        public string getcorr() { return correo; }
    }
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int indice = 0;
        agenda[] contactos = new agenda[100];
        int pos = 0;
        string estado = "";
        int pe = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            tsl2.Text += DateTime.Now.ToString();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" JASON DESARROLLADOR ");
        }

        private void tsl1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" DATOS PERSONALES ");
        }

       

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }

        private void btnnuevo_Click(object sender, EventArgs e)
        {
            
        }

      


      
    }
}
