﻿namespace FORMULARIO
{
    partial class frmEjer1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCierra1 = new System.Windows.Forms.Button();
            this.txtLim = new System.Windows.Forms.TextBox();
            this.lstPrim = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCierra1
            // 
            this.btnCierra1.Location = new System.Drawing.Point(180, 227);
            this.btnCierra1.Name = "btnCierra1";
            this.btnCierra1.Size = new System.Drawing.Size(75, 23);
            this.btnCierra1.TabIndex = 0;
            this.btnCierra1.Text = "CERRAR";
            this.btnCierra1.UseVisualStyleBackColor = true;
            this.btnCierra1.Click += new System.EventHandler(this.btnCierra1_Click);
            // 
            // txtLim
            // 
            this.txtLim.Location = new System.Drawing.Point(76, 40);
            this.txtLim.Name = "txtLim";
            this.txtLim.Size = new System.Drawing.Size(100, 20);
            this.txtLim.TabIndex = 1;
            // 
            // lstPrim
            // 
            this.lstPrim.FormattingEnabled = true;
            this.lstPrim.Location = new System.Drawing.Point(51, 96);
            this.lstPrim.Name = "lstPrim";
            this.lstPrim.Size = new System.Drawing.Size(96, 147);
            this.lstPrim.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "LIMITE";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(197, 38);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "GENERAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(197, 80);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiar.TabIndex = 5;
            this.btnLimpiar.Text = "LIMPIAR";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // frmEjer1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(295, 270);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstPrim);
            this.Controls.Add(this.txtLim);
            this.Controls.Add(this.btnCierra1);
            this.Name = "frmEjer1";
            this.Text = "frmEjer1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCierra1;
        private System.Windows.Forms.TextBox txtLim;
        private System.Windows.Forms.ListBox lstPrim;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnLimpiar;
    }
}