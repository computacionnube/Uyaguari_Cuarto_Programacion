﻿namespace Agenda_Estudiantil
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.texttel = new System.Windows.Forms.TextBox();
            this.cBxnacionalida = new System.Windows.Forms.ComboBox();
            this.textced = new System.Windows.Forms.TextBox();
            this.textdirec = new System.Windows.Forms.TextBox();
            this.textapeli = new System.Windows.Forms.TextBox();
            this.textNombre = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textedad = new System.Windows.Forms.TextBox();
            this.textmail = new System.Windows.Forms.TextBox();
            this.textunidda = new System.Windows.Forms.TextBox();
            this.grBGenero = new System.Windows.Forms.GroupBox();
            this.checkF = new System.Windows.Forms.CheckBox();
            this.checkM = new System.Windows.Forms.CheckBox();
            this.grBTipo_sangre = new System.Windows.Forms.GroupBox();
            this.checAB2 = new System.Windows.Forms.CheckBox();
            this.checkORH2 = new System.Windows.Forms.CheckBox();
            this.checAB = new System.Windows.Forms.CheckBox();
            this.checORH = new System.Windows.Forms.CheckBox();
            this.butnew = new System.Windows.Forms.Button();
            this.butEliminar = new System.Windows.Forms.Button();
            this.butEdd = new System.Windows.Forms.Button();
            this.butAdd = new System.Windows.Forms.Button();
            this.dataRegistro = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Parroquia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cedula = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Seg_Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Apellido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Seg_Apellido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Telefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Direccion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sexo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Edad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Estado_Civil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ti_Sangre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Deporte = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Joby = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Materia_Favorita = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Propiedad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textSegunNombre = new System.Windows.Forms.TextBox();
            this.textseguenAple = new System.Windows.Forms.TextBox();
            this.butsiguiente = new System.Windows.Forms.Button();
            this.butcerrar = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unidad_Educativa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Especialidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Carrera = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ciclo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Profesor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tel_Institucion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Direc_Institucion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Materias = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Provincia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cbxEstadoCi = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textmaterFav = new System.Windows.Forms.TextBox();
            this.textjoby = new System.Windows.Forms.TextBox();
            this.textdeporFavo = new System.Windows.Forms.TextBox();
            this.cbopropfam = new System.Windows.Forms.ComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label18 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textedit = new System.Windows.Forms.TextBox();
            this.textdigito = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grBGenero.SuspendLayout();
            this.grBTipo_sangre.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataRegistro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(113, 220);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 15);
            this.label6.TabIndex = 11;
            this.label6.Text = "Telefono";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(471, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Parroquia";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(474, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "Cedula";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(474, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Direccion";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(113, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Primer Apellidos";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(111, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "Primer Nombre";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(2, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 148);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 165);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Fotografia";
            // 
            // texttel
            // 
            this.texttel.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.texttel.Location = new System.Drawing.Point(197, 220);
            this.texttel.Name = "texttel";
            this.texttel.Size = new System.Drawing.Size(151, 23);
            this.texttel.TabIndex = 19;
            this.toolTip1.SetToolTip(this.texttel, "Tlefono");
            this.texttel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.texttel_KeyPress);
            // 
            // cBxnacionalida
            // 
            this.cBxnacionalida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cBxnacionalida.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cBxnacionalida.FormattingEnabled = true;
            this.cBxnacionalida.Items.AddRange(new object[] {
            "El Sagrario",
            "Sucre",
            "El Valle",
            "San Sebastián",
            "Punzara",
            "Carigán"});
            this.cBxnacionalida.Location = new System.Drawing.Point(554, 93);
            this.cBxnacionalida.Name = "cBxnacionalida";
            this.cBxnacionalida.Size = new System.Drawing.Size(121, 23);
            this.cBxnacionalida.TabIndex = 18;
            this.cBxnacionalida.Text = "Seleccione";
            this.toolTip1.SetToolTip(this.cBxnacionalida, "Parroquia");
            // 
            // textced
            // 
            this.textced.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textced.Location = new System.Drawing.Point(554, 57);
            this.textced.Name = "textced";
            this.textced.Size = new System.Drawing.Size(100, 23);
            this.textced.TabIndex = 17;
            this.toolTip1.SetToolTip(this.textced, "Cedula");
            this.textced.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textced_KeyPress);
            // 
            // textdirec
            // 
            this.textdirec.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textdirec.Location = new System.Drawing.Point(554, 14);
            this.textdirec.Name = "textdirec";
            this.textdirec.Size = new System.Drawing.Size(143, 23);
            this.textdirec.TabIndex = 16;
            this.toolTip1.SetToolTip(this.textdirec, "Direccion");
            this.textdirec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textdirec_KeyPress);
            // 
            // textapeli
            // 
            this.textapeli.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textapeli.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textapeli.Location = new System.Drawing.Point(258, 69);
            this.textapeli.Name = "textapeli";
            this.textapeli.Size = new System.Drawing.Size(157, 23);
            this.textapeli.TabIndex = 15;
            this.toolTip1.SetToolTip(this.textapeli, "Primer Apellido");
            this.textapeli.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textapeli_KeyPress);
            // 
            // textNombre
            // 
            this.textNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textNombre.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNombre.Location = new System.Drawing.Point(258, 10);
            this.textNombre.Name = "textNombre";
            this.textNombre.Size = new System.Drawing.Size(157, 23);
            this.textNombre.TabIndex = 14;
            this.toolTip1.SetToolTip(this.textNombre, "Primer Nombre");
            this.textNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textNombre_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(705, 115);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 15);
            this.label12.TabIndex = 25;
            this.label12.Text = "Estado civil";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(113, 136);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 15);
            this.label11.TabIndex = 24;
            this.label11.Text = "Edad";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(113, 176);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 15);
            this.label8.TabIndex = 21;
            this.label8.Text = "Mail";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(348, 254);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(114, 15);
            this.label13.TabIndex = 20;
            this.label13.Text = "Unidad Educativa";
            // 
            // textedad
            // 
            this.textedad.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textedad.Location = new System.Drawing.Point(177, 128);
            this.textedad.Name = "textedad";
            this.textedad.Size = new System.Drawing.Size(109, 23);
            this.textedad.TabIndex = 30;
            this.toolTip1.SetToolTip(this.textedad, "Edad");
            this.textedad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textedad_KeyPress);
            // 
            // textmail
            // 
            this.textmail.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textmail.Location = new System.Drawing.Point(160, 168);
            this.textmail.Name = "textmail";
            this.textmail.Size = new System.Drawing.Size(188, 23);
            this.textmail.TabIndex = 29;
            this.toolTip1.SetToolTip(this.textmail, "Mail");
            this.textmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textmail_KeyPress);
            // 
            // textunidda
            // 
            this.textunidda.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textunidda.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textunidda.Location = new System.Drawing.Point(484, 250);
            this.textunidda.Name = "textunidda";
            this.textunidda.Size = new System.Drawing.Size(225, 23);
            this.textunidda.TabIndex = 28;
            this.toolTip1.SetToolTip(this.textunidda, "Unidad Educativa");
            this.textunidda.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textunidda_KeyPress);
            // 
            // grBGenero
            // 
            this.grBGenero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grBGenero.Controls.Add(this.checkF);
            this.grBGenero.Controls.Add(this.checkM);
            this.grBGenero.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grBGenero.Location = new System.Drawing.Point(744, 10);
            this.grBGenero.Name = "grBGenero";
            this.grBGenero.Size = new System.Drawing.Size(102, 83);
            this.grBGenero.TabIndex = 35;
            this.grBGenero.TabStop = false;
            this.grBGenero.Text = "Genero";
            this.toolTip1.SetToolTip(this.grBGenero, "Genero");
            // 
            // checkF
            // 
            this.checkF.AutoSize = true;
            this.checkF.Checked = true;
            this.checkF.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkF.Location = new System.Drawing.Point(11, 51);
            this.checkF.Name = "checkF";
            this.checkF.Size = new System.Drawing.Size(33, 19);
            this.checkF.TabIndex = 1;
            this.checkF.Text = "F";
            this.toolTip1.SetToolTip(this.checkF, "Femenino");
            this.checkF.UseVisualStyleBackColor = true;
            // 
            // checkM
            // 
            this.checkM.AutoSize = true;
            this.checkM.Checked = true;
            this.checkM.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkM.Location = new System.Drawing.Point(11, 26);
            this.checkM.Name = "checkM";
            this.checkM.Size = new System.Drawing.Size(36, 19);
            this.checkM.TabIndex = 0;
            this.checkM.Text = "M";
            this.toolTip1.SetToolTip(this.checkM, "Masculino");
            this.checkM.UseVisualStyleBackColor = true;
            // 
            // grBTipo_sangre
            // 
            this.grBTipo_sangre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.grBTipo_sangre.Controls.Add(this.checAB2);
            this.grBTipo_sangre.Controls.Add(this.checkORH2);
            this.grBTipo_sangre.Controls.Add(this.checAB);
            this.grBTipo_sangre.Controls.Add(this.checORH);
            this.grBTipo_sangre.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grBTipo_sangre.Location = new System.Drawing.Point(462, 153);
            this.grBTipo_sangre.Name = "grBTipo_sangre";
            this.grBTipo_sangre.Size = new System.Drawing.Size(176, 88);
            this.grBTipo_sangre.TabIndex = 34;
            this.grBTipo_sangre.TabStop = false;
            this.grBTipo_sangre.Text = "Tipo Sangre";
            this.toolTip1.SetToolTip(this.grBTipo_sangre, "Tipo De Sangre");
            // 
            // checAB2
            // 
            this.checAB2.AutoSize = true;
            this.checAB2.Location = new System.Drawing.Point(82, 66);
            this.checAB2.Name = "checAB2";
            this.checAB2.Size = new System.Drawing.Size(47, 19);
            this.checAB2.TabIndex = 3;
            this.checAB2.Text = "AB-";
            this.checAB2.UseVisualStyleBackColor = true;
            // 
            // checkORH2
            // 
            this.checkORH2.AutoSize = true;
            this.checkORH2.Location = new System.Drawing.Point(87, 23);
            this.checkORH2.Name = "checkORH2";
            this.checkORH2.Size = new System.Drawing.Size(57, 19);
            this.checkORH2.TabIndex = 2;
            this.checkORH2.Text = "ORH-";
            this.checkORH2.UseVisualStyleBackColor = true;
            // 
            // checAB
            // 
            this.checAB.AutoSize = true;
            this.checAB.Location = new System.Drawing.Point(20, 66);
            this.checAB.Name = "checAB";
            this.checAB.Size = new System.Drawing.Size(51, 19);
            this.checAB.TabIndex = 1;
            this.checAB.Text = "AB+";
            this.checAB.UseVisualStyleBackColor = true;
            // 
            // checORH
            // 
            this.checORH.AutoSize = true;
            this.checORH.Location = new System.Drawing.Point(20, 24);
            this.checORH.Name = "checORH";
            this.checORH.Size = new System.Drawing.Size(61, 19);
            this.checORH.TabIndex = 0;
            this.checORH.Text = "ORH+";
            this.checORH.UseVisualStyleBackColor = true;
            // 
            // butnew
            // 
            this.butnew.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butnew.Location = new System.Drawing.Point(1108, 143);
            this.butnew.Name = "butnew";
            this.butnew.Size = new System.Drawing.Size(93, 35);
            this.butnew.TabIndex = 39;
            this.butnew.Text = "Nuevo";
            this.toolTip1.SetToolTip(this.butnew, "Nuevo");
            this.butnew.UseVisualStyleBackColor = true;
            this.butnew.Click += new System.EventHandler(this.butnew_Click);
            // 
            // butEliminar
            // 
            this.butEliminar.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butEliminar.Location = new System.Drawing.Point(1108, 99);
            this.butEliminar.Name = "butEliminar";
            this.butEliminar.Size = new System.Drawing.Size(93, 34);
            this.butEliminar.TabIndex = 38;
            this.butEliminar.Text = "Eliminar";
            this.toolTip1.SetToolTip(this.butEliminar, "Eliminar");
            this.butEliminar.UseVisualStyleBackColor = true;
            this.butEliminar.Click += new System.EventHandler(this.butEliminar_Click);
            // 
            // butEdd
            // 
            this.butEdd.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butEdd.Location = new System.Drawing.Point(1108, 53);
            this.butEdd.Name = "butEdd";
            this.butEdd.Size = new System.Drawing.Size(93, 32);
            this.butEdd.TabIndex = 37;
            this.butEdd.Text = "Editar";
            this.toolTip1.SetToolTip(this.butEdd, "Editar");
            this.butEdd.UseVisualStyleBackColor = true;
            this.butEdd.Click += new System.EventHandler(this.butEdd_Click);
            // 
            // butAdd
            // 
            this.butAdd.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butAdd.Location = new System.Drawing.Point(1108, 14);
            this.butAdd.Name = "butAdd";
            this.butAdd.Size = new System.Drawing.Size(93, 28);
            this.butAdd.TabIndex = 36;
            this.butAdd.Text = "Agregar";
            this.toolTip1.SetToolTip(this.butAdd, "Agregar");
            this.butAdd.UseVisualStyleBackColor = true;
            this.butAdd.Click += new System.EventHandler(this.butAdd_Click);
            // 
            // dataRegistro
            // 
            this.dataRegistro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataRegistro.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Parroquia,
            this.Cedula,
            this.Nombre,
            this.Seg_Nombre,
            this.Apellido,
            this.Seg_Apellido,
            this.Telefono,
            this.Direccion,
            this.Mail,
            this.Sexo,
            this.Edad,
            this.Estado_Civil,
            this.Ti_Sangre,
            this.Unidad,
            this.Deporte,
            this.Joby,
            this.Materia_Favorita,
            this.Propiedad});
            this.dataRegistro.Location = new System.Drawing.Point(2, 308);
            this.dataRegistro.Name = "dataRegistro";
            this.dataRegistro.Size = new System.Drawing.Size(1280, 150);
            this.dataRegistro.TabIndex = 40;
            this.dataRegistro.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataRegistro_CellClick);
            // 
            // Column1
            // 
            this.Column1.FillWeight = 30F;
            this.Column1.HeaderText = "#";
            this.Column1.Name = "Column1";
            this.Column1.Width = 30;
            // 
            // Parroquia
            // 
            this.Parroquia.HeaderText = "Parroquia";
            this.Parroquia.Name = "Parroquia";
            // 
            // Cedula
            // 
            this.Cedula.HeaderText = "Cedula";
            this.Cedula.Name = "Cedula";
            // 
            // Nombre
            // 
            this.Nombre.FillWeight = 140F;
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.Name = "Nombre";
            this.Nombre.Width = 140;
            // 
            // Seg_Nombre
            // 
            this.Seg_Nombre.HeaderText = "Seg_Nombre";
            this.Seg_Nombre.Name = "Seg_Nombre";
            this.Seg_Nombre.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Apellido
            // 
            this.Apellido.FillWeight = 140F;
            this.Apellido.HeaderText = "Apellido";
            this.Apellido.Name = "Apellido";
            this.Apellido.Width = 140;
            // 
            // Seg_Apellido
            // 
            this.Seg_Apellido.HeaderText = "Seg_Apellido";
            this.Seg_Apellido.Name = "Seg_Apellido";
            // 
            // Telefono
            // 
            this.Telefono.HeaderText = "Telefono";
            this.Telefono.Name = "Telefono";
            // 
            // Direccion
            // 
            this.Direccion.FillWeight = 140F;
            this.Direccion.HeaderText = "Direccion";
            this.Direccion.Name = "Direccion";
            this.Direccion.Width = 140;
            // 
            // Mail
            // 
            this.Mail.FillWeight = 140F;
            this.Mail.HeaderText = "Mail";
            this.Mail.Name = "Mail";
            this.Mail.Width = 140;
            // 
            // Sexo
            // 
            this.Sexo.HeaderText = "Sexo";
            this.Sexo.Name = "Sexo";
            // 
            // Edad
            // 
            this.Edad.FillWeight = 60F;
            this.Edad.HeaderText = "Edad";
            this.Edad.Name = "Edad";
            this.Edad.Width = 60;
            // 
            // Estado_Civil
            // 
            this.Estado_Civil.HeaderText = "Estado_Civil";
            this.Estado_Civil.Name = "Estado_Civil";
            // 
            // Ti_Sangre
            // 
            this.Ti_Sangre.HeaderText = "Tipo_Sangre";
            this.Ti_Sangre.Name = "Ti_Sangre";
            // 
            // Unidad
            // 
            this.Unidad.HeaderText = "Unidad Educativa";
            this.Unidad.Name = "Unidad";
            // 
            // Deporte
            // 
            this.Deporte.HeaderText = "Deporte";
            this.Deporte.Name = "Deporte";
            // 
            // Joby
            // 
            this.Joby.HeaderText = "Joby";
            this.Joby.Name = "Joby";
            // 
            // Materia_Favorita
            // 
            this.Materia_Favorita.HeaderText = "Materia_Favorita";
            this.Materia_Favorita.Name = "Materia_Favorita";
            // 
            // Propiedad
            // 
            this.Propiedad.HeaderText = "Propiedad";
            this.Propiedad.Name = "Propiedad";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(110, 39);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(116, 15);
            this.label14.TabIndex = 41;
            this.label14.Text = "Segundo Nombre";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(111, 102);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(117, 15);
            this.label15.TabIndex = 42;
            this.label15.Text = "Segundo Apellido";
            // 
            // textSegunNombre
            // 
            this.textSegunNombre.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textSegunNombre.Location = new System.Drawing.Point(258, 40);
            this.textSegunNombre.Name = "textSegunNombre";
            this.textSegunNombre.Size = new System.Drawing.Size(157, 23);
            this.textSegunNombre.TabIndex = 43;
            this.toolTip1.SetToolTip(this.textSegunNombre, "Segundo Nombre");
            this.textSegunNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textSegunNombre_KeyPress);
            // 
            // textseguenAple
            // 
            this.textseguenAple.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textseguenAple.Location = new System.Drawing.Point(258, 99);
            this.textseguenAple.Name = "textseguenAple";
            this.textseguenAple.Size = new System.Drawing.Size(157, 23);
            this.textseguenAple.TabIndex = 44;
            this.toolTip1.SetToolTip(this.textseguenAple, "Segundo Apellido");
            this.textseguenAple.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textseguenAple_KeyPress);
            // 
            // butsiguiente
            // 
            this.butsiguiente.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butsiguiente.Location = new System.Drawing.Point(1108, 195);
            this.butsiguiente.Name = "butsiguiente";
            this.butsiguiente.Size = new System.Drawing.Size(93, 32);
            this.butsiguiente.TabIndex = 46;
            this.butsiguiente.Text = "Next";
            this.toolTip1.SetToolTip(this.butsiguiente, "Next");
            this.butsiguiente.UseVisualStyleBackColor = true;
            this.butsiguiente.Click += new System.EventHandler(this.butsiguiente_Click);
            // 
            // butcerrar
            // 
            this.butcerrar.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butcerrar.Location = new System.Drawing.Point(1108, 234);
            this.butcerrar.Name = "butcerrar";
            this.butcerrar.Size = new System.Drawing.Size(93, 35);
            this.butcerrar.TabIndex = 48;
            this.butcerrar.Text = "Salir";
            this.toolTip1.SetToolTip(this.butcerrar, "Salir");
            this.butcerrar.UseVisualStyleBackColor = true;
            this.butcerrar.Click += new System.EventHandler(this.butcerrar_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Unidad_Educativa,
            this.Especialidad,
            this.Carrera,
            this.Ciclo,
            this.Profesor,
            this.Tel_Institucion,
            this.Direc_Institucion,
            this.dataGridViewTextBoxColumn2,
            this.Materias,
            this.Fax,
            this.Provincia});
            this.dataGridView1.Location = new System.Drawing.Point(2, 489);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1270, 150);
            this.dataGridView1.TabIndex = 74;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 50F;
            this.dataGridViewTextBoxColumn1.HeaderText = "#";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // Unidad_Educativa
            // 
            this.Unidad_Educativa.FillWeight = 150F;
            this.Unidad_Educativa.HeaderText = "Unidad_Educativa";
            this.Unidad_Educativa.Name = "Unidad_Educativa";
            this.Unidad_Educativa.Width = 150;
            // 
            // Especialidad
            // 
            this.Especialidad.FillWeight = 120F;
            this.Especialidad.HeaderText = "Especialidad";
            this.Especialidad.Name = "Especialidad";
            this.Especialidad.Width = 120;
            // 
            // Carrera
            // 
            this.Carrera.HeaderText = "Carrera";
            this.Carrera.Name = "Carrera";
            // 
            // Ciclo
            // 
            this.Ciclo.HeaderText = "Ciclo";
            this.Ciclo.Name = "Ciclo";
            // 
            // Profesor
            // 
            this.Profesor.HeaderText = "Profesor";
            this.Profesor.Name = "Profesor";
            // 
            // Tel_Institucion
            // 
            this.Tel_Institucion.HeaderText = "Tel_Institucion";
            this.Tel_Institucion.Name = "Tel_Institucion";
            // 
            // Direc_Institucion
            // 
            this.Direc_Institucion.HeaderText = "Direc_Institucion";
            this.Direc_Institucion.Name = "Direc_Institucion";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 140F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Mail";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 140;
            // 
            // Materias
            // 
            this.Materias.FillWeight = 200F;
            this.Materias.HeaderText = "Materias";
            this.Materias.Name = "Materias";
            this.Materias.Width = 300;
            // 
            // Fax
            // 
            this.Fax.HeaderText = "Fax";
            this.Fax.Name = "Fax";
            // 
            // Provincia
            // 
            this.Provincia.HeaderText = "Provincia";
            this.Provincia.Name = "Provincia";
            // 
            // cbxEstadoCi
            // 
            this.cbxEstadoCi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cbxEstadoCi.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxEstadoCi.FormattingEnabled = true;
            this.cbxEstadoCi.Items.AddRange(new object[] {
            "Soltero",
            "Viudo",
            "Casado"});
            this.cbxEstadoCi.Location = new System.Drawing.Point(804, 110);
            this.cbxEstadoCi.Name = "cbxEstadoCi";
            this.cbxEstadoCi.Size = new System.Drawing.Size(121, 23);
            this.cbxEstadoCi.TabIndex = 75;
            this.cbxEstadoCi.Text = "Estado Civil";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(732, 188);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 15);
            this.label10.TabIndex = 78;
            this.label10.Text = "Materia Prferida";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(741, 233);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(36, 15);
            this.label16.TabIndex = 79;
            this.label16.Text = "Joby";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(732, 266);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(116, 15);
            this.label17.TabIndex = 80;
            this.label17.Text = "Deporte Favorito";
            // 
            // textmaterFav
            // 
            this.textmaterFav.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textmaterFav.Location = new System.Drawing.Point(868, 188);
            this.textmaterFav.Name = "textmaterFav";
            this.textmaterFav.Size = new System.Drawing.Size(212, 23);
            this.textmaterFav.TabIndex = 81;
            this.toolTip1.SetToolTip(this.textmaterFav, "Materia Preferida");
            this.textmaterFav.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textmaterFav_KeyPress);
            // 
            // textjoby
            // 
            this.textjoby.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textjoby.Location = new System.Drawing.Point(868, 220);
            this.textjoby.Name = "textjoby";
            this.textjoby.Size = new System.Drawing.Size(212, 23);
            this.textjoby.TabIndex = 82;
            this.toolTip1.SetToolTip(this.textjoby, "Joby");
            this.textjoby.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textjoby_KeyPress);
            // 
            // textdeporFavo
            // 
            this.textdeporFavo.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textdeporFavo.Location = new System.Drawing.Point(868, 258);
            this.textdeporFavo.Name = "textdeporFavo";
            this.textdeporFavo.Size = new System.Drawing.Size(212, 23);
            this.textdeporFavo.TabIndex = 83;
            this.toolTip1.SetToolTip(this.textdeporFavo, "Deporte Favorito");
            this.textdeporFavo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textdeporFavo_KeyPress);
            // 
            // cbopropfam
            // 
            this.cbopropfam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cbopropfam.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbopropfam.FormattingEnabled = true;
            this.cbopropfam.Items.AddRange(new object[] {
            "PROPIA",
            "DE RENTA",
            "PRESTADA"});
            this.cbopropfam.Location = new System.Drawing.Point(563, 122);
            this.cbopropfam.Name = "cbopropfam";
            this.cbopropfam.Size = new System.Drawing.Size(121, 23);
            this.cbopropfam.TabIndex = 84;
            this.toolTip1.SetToolTip(this.cbopropfam, "Propiedad");
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(459, 130);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(70, 15);
            this.label18.TabIndex = 85;
            this.label18.Text = "Propiedad";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(801, 163);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(170, 15);
            this.label9.TabIndex = 86;
            this.label9.Text = "GUSTOS DEL ESTUDIANTE";
            // 
            // textedit
            // 
            this.textedit.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textedit.Location = new System.Drawing.Point(977, 76);
            this.textedit.Name = "textedit";
            this.textedit.Size = new System.Drawing.Size(100, 23);
            this.textedit.TabIndex = 87;
            this.toolTip1.SetToolTip(this.textedit, "Primer Dijito de la cedula");
            // 
            // textdigito
            // 
            this.textdigito.Font = new System.Drawing.Font("Lucida Bright", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textdigito.Location = new System.Drawing.Point(977, 138);
            this.textdigito.Name = "textdigito";
            this.textdigito.Size = new System.Drawing.Size(100, 23);
            this.textdigito.TabIndex = 88;
            this.toolTip1.SetToolTip(this.textdigito, "Seleccion Editar");
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(954, 57);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(126, 13);
            this.label19.TabIndex = 89;
            this.label19.Text = "Primer digito de la Cedula";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(965, 116);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(105, 13);
            this.label20.TabIndex = 90;
            this.label20.Text = "seleccion para editar";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(943, 33);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(84, 13);
            this.label21.TabIndex = 91;
            this.label21.Text = "OBSERVACION";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(1284, 700);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textdigito);
            this.Controls.Add(this.textedit);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.cbopropfam);
            this.Controls.Add(this.textdeporFavo);
            this.Controls.Add(this.textjoby);
            this.Controls.Add(this.textmaterFav);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cbxEstadoCi);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.butcerrar);
            this.Controls.Add(this.butsiguiente);
            this.Controls.Add(this.textseguenAple);
            this.Controls.Add(this.textSegunNombre);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.dataRegistro);
            this.Controls.Add(this.butnew);
            this.Controls.Add(this.butEliminar);
            this.Controls.Add(this.butEdd);
            this.Controls.Add(this.butAdd);
            this.Controls.Add(this.grBGenero);
            this.Controls.Add(this.grBTipo_sangre);
            this.Controls.Add(this.textedad);
            this.Controls.Add(this.textmail);
            this.Controls.Add(this.textunidda);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.texttel);
            this.Controls.Add(this.cBxnacionalida);
            this.Controls.Add(this.textced);
            this.Controls.Add(this.textdirec);
            this.Controls.Add(this.textapeli);
            this.Controls.Add(this.textNombre);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Datos Personales ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grBGenero.ResumeLayout(false);
            this.grBGenero.PerformLayout();
            this.grBTipo_sangre.ResumeLayout(false);
            this.grBTipo_sangre.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataRegistro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox grBGenero;
        private System.Windows.Forms.Button butnew;
        private System.Windows.Forms.Button butEliminar;
        private System.Windows.Forms.Button butEdd;
        private System.Windows.Forms.Button butAdd;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button butcerrar;
        public System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.TextBox texttel;
        public System.Windows.Forms.ComboBox cBxnacionalida;
        public System.Windows.Forms.TextBox textced;
        public System.Windows.Forms.TextBox textdirec;
        public System.Windows.Forms.TextBox textapeli;
        public System.Windows.Forms.TextBox textNombre;
        public System.Windows.Forms.TextBox textedad;
        public System.Windows.Forms.TextBox textmail;
        public System.Windows.Forms.TextBox textunidda;
        public System.Windows.Forms.CheckBox checkF;
        public System.Windows.Forms.CheckBox checkM;
        public System.Windows.Forms.GroupBox grBTipo_sangre;
        public System.Windows.Forms.CheckBox checAB2;
        public System.Windows.Forms.CheckBox checkORH2;
        public System.Windows.Forms.CheckBox checAB;
        public System.Windows.Forms.CheckBox checORH;
        public System.Windows.Forms.DataGridView dataRegistro;
        public System.Windows.Forms.TextBox textSegunNombre;
        public System.Windows.Forms.TextBox textseguenAple;
        public System.Windows.Forms.Button butsiguiente;
        public System.Windows.Forms.ComboBox cbxEstadoCi;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textmaterFav;
        private System.Windows.Forms.TextBox textjoby;
        private System.Windows.Forms.TextBox textdeporFavo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unidad_Educativa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Especialidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Carrera;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ciclo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Profesor;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tel_Institucion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Direc_Institucion;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Materias;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fax;
        private System.Windows.Forms.DataGridViewTextBoxColumn Provincia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Parroquia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cedula;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Seg_Nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Apellido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Seg_Apellido;
        private System.Windows.Forms.DataGridViewTextBoxColumn Telefono;
        private System.Windows.Forms.DataGridViewTextBoxColumn Direccion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mail;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sexo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Edad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Estado_Civil;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ti_Sangre;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Deporte;
        private System.Windows.Forms.DataGridViewTextBoxColumn Joby;
        private System.Windows.Forms.DataGridViewTextBoxColumn Materia_Favorita;
        private System.Windows.Forms.DataGridViewTextBoxColumn Propiedad;
        public System.Windows.Forms.ComboBox cbopropfam;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox textedit;
        public System.Windows.Forms.TextBox textdigito;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
    }
}

