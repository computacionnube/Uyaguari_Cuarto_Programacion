﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Temporizador
{
    public partial class Form1 : Form
    {
        int dd, ss, mm, hh = 0;
        int fa=0;
        public Form1()
        {
            InitializeComponent();
        }
        
        private void btnIniciar_Click(object sender, EventArgs e)
        {
            reloj.Start();
        }

        private void btnDetener_Click(object sender, EventArgs e)
        {
            reloj.Stop();
        }

        private void reloj_Tick(object sender, EventArgs e)
        {
            string ht, mt, st;
            dd++;
            if (dd==0)
            {
                dd = 0;
                ss++;
                if (ss==60)
                {
                    mm++;
                    ss = 0;
                }
                if (mm==60)
                {
                    hh++;
                }
            }
            if (hh<10)
            {
                ht = "0" + Convert.ToString(hh);
            }
            else
            {
                ht = Convert.ToString(hh);
            }
            if (mm<10)
            {
                mt = "0" + Convert.ToString(mm);
            }
            else
            {
                mt = Convert.ToString(mm);
            }
            if (ss<10)
            {
                st = "0" + Convert.ToString(ss);
            }
            else
            {
                st=Convert.ToString(ss);
                
            }
            txttiempo.Text = ht + ":" + mt + ":" + st + ":" + Convert.ToString(dd);
        }

        private void btnEncerar_Click(object sender, EventArgs e)
        {
            reloj.Stop();
            dd = mm = ss = hh = 0;
            txttiempo.Clear();
            txttiempo.Text="00.00.00.0";
        }
        
        private void dtpTimer_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void dtpFijaHora_ValueChanged(object sender, EventArgs e)
        {
           
        }

        private void Alarma_Tick(object sender, EventArgs e)
        {
            dtpTimer.Value = DateTime.Now;
            if (fa == 1)
            {
                if (dtpTimer.Value.Second == dtpFijarHora.Value.Second && dtpTimer.Value.Minute == dtpFijarHora.Value.Minute && dtpTimer.Value.Hour == dtpFijarHora.Value.Hour)
                {
                    fa = 0;
                    MessageBox.Show("ALARMA");
                    
                }
            }
        }
        private void btnFijaralarma_Click(object sender, EventArgs e)
        {
            fa = 1;
        }
        //Bomba
        int  m1, h1 = 0;
        int s1 = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            s1 = Convert.ToInt32(NudSegundos.Value);
            m1 = Convert.ToInt32(NudMinutos.Value);
            h1 = Convert.ToInt32(NudSegundos.Value);
            Bomba.Start();
        }

        private void btnDesactivar_Click(object sender, EventArgs e)
        {
            Bomba.Stop();
        }

        private void Bomba_Tick(object sender, EventArgs e)
        {
            s1--;
            if (s1<=0)
            {
                if (m1>0)
                {
                    m1--;
                    s1 = 59;
                }
            }
            if (m1==0)
            {
                if (h1>0)
                {
                    h1--;
                    m1 = 59;
                    
                }
            }
            NudHoras.Value = Convert.ToDecimal(h1);
            NudMinutos.Value = Convert.ToDecimal(m1);
            NudSegundos.Value = Convert.ToDecimal(s1);
            if (s1==0 && m1==0 && h1==0)
            {
                Bomba.Stop();
                MessageBox.Show("termino el tiempo", "Bomba", MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }

        }

        private void txttiempo_TextChanged(object sender, EventArgs e)
        {

        }

        
    }
}
