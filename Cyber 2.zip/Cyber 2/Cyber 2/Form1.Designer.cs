﻿namespace Cyber_2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.Button btn1;
            System.Windows.Forms.Button btn5;
            System.Windows.Forms.Button btn4;
            System.Windows.Forms.Button btn3;
            System.Windows.Forms.Button btn2;
            System.Windows.Forms.Button btn6;
            this.btnPc1 = new System.Windows.Forms.Button();
            this.btnPc2 = new System.Windows.Forms.Button();
            this.btnPc3 = new System.Windows.Forms.Button();
            this.btnPc4 = new System.Windows.Forms.Button();
            this.btnPc5 = new System.Windows.Forms.Button();
            this.btnPc6 = new System.Windows.Forms.Button();
            this.Nudhoras = new System.Windows.Forms.NumericUpDown();
            this.NudMinutos = new System.Windows.Forms.NumericUpDown();
            this.txtCostoHora = new System.Windows.Forms.TextBox();
            this.txtLibres = new System.Windows.Forms.TextBox();
            this.txtOcupadas = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtEstado1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtValorCob2 = new System.Windows.Forms.TextBox();
            this.txtTimeFal2 = new System.Windows.Forms.TextBox();
            this.txtTimeTot2 = new System.Windows.Forms.TextBox();
            this.txtTimeUs2 = new System.Windows.Forms.TextBox();
            this.txtEstado2 = new System.Windows.Forms.TextBox();
            this.txtValorCob1 = new System.Windows.Forms.TextBox();
            this.txtTimeFal1 = new System.Windows.Forms.TextBox();
            this.txtTimeTot1 = new System.Windows.Forms.TextBox();
            this.txtTimeUs1 = new System.Windows.Forms.TextBox();
            this.txtTimeTot3 = new System.Windows.Forms.TextBox();
            this.txtTimeUs3 = new System.Windows.Forms.TextBox();
            this.txtTimeFal3 = new System.Windows.Forms.TextBox();
            this.txtTimeU4 = new System.Windows.Forms.TextBox();
            this.txtValorCob3 = new System.Windows.Forms.TextBox();
            this.txtTimeTot4 = new System.Windows.Forms.TextBox();
            this.txtTimeFal5 = new System.Windows.Forms.TextBox();
            this.txtTimeTot5 = new System.Windows.Forms.TextBox();
            this.txtTimeUs5 = new System.Windows.Forms.TextBox();
            this.txtEstado5 = new System.Windows.Forms.TextBox();
            this.txtValorCob4 = new System.Windows.Forms.TextBox();
            this.txtTimeFal4 = new System.Windows.Forms.TextBox();
            this.txtEstado4 = new System.Windows.Forms.TextBox();
            this.txtEstado3 = new System.Windows.Forms.TextBox();
            this.txtEstado6 = new System.Windows.Forms.TextBox();
            this.txtValorCob5 = new System.Windows.Forms.TextBox();
            this.txtTimeFal6 = new System.Windows.Forms.TextBox();
            this.txtTimeTot6 = new System.Windows.Forms.TextBox();
            this.txtTimeUs6 = new System.Windows.Forms.TextBox();
            this.txtValorCob6 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lst = new System.Windows.Forms.ListBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.TimeInicio = new System.Windows.Forms.Timer(this.components);
            this.Nudsegundos = new System.Windows.Forms.NumericUpDown();
            this.lblUso1 = new System.Windows.Forms.Label();
            this.TimePC1 = new System.Windows.Forms.Timer(this.components);
            btn1 = new System.Windows.Forms.Button();
            btn5 = new System.Windows.Forms.Button();
            btn4 = new System.Windows.Forms.Button();
            btn3 = new System.Windows.Forms.Button();
            btn2 = new System.Windows.Forms.Button();
            btn6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Nudhoras)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudMinutos)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Nudsegundos)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPc1
            // 
            this.btnPc1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPc1.BackgroundImage")));
            this.btnPc1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPc1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPc1.ForeColor = System.Drawing.Color.Red;
            this.btnPc1.Location = new System.Drawing.Point(12, 4);
            this.btnPc1.Name = "btnPc1";
            this.btnPc1.Size = new System.Drawing.Size(55, 55);
            this.btnPc1.TabIndex = 0;
            this.btnPc1.Text = "PC1";
            this.btnPc1.UseVisualStyleBackColor = true;
            this.btnPc1.Click += new System.EventHandler(this.btnPc1_Click);
            // 
            // btnPc2
            // 
            this.btnPc2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPc2.BackgroundImage")));
            this.btnPc2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPc2.ForeColor = System.Drawing.Color.Red;
            this.btnPc2.Location = new System.Drawing.Point(107, 4);
            this.btnPc2.Name = "btnPc2";
            this.btnPc2.Size = new System.Drawing.Size(55, 55);
            this.btnPc2.TabIndex = 1;
            this.btnPc2.Text = "PC2";
            this.btnPc2.UseVisualStyleBackColor = true;
            // 
            // btnPc3
            // 
            this.btnPc3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPc3.BackgroundImage")));
            this.btnPc3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPc3.ForeColor = System.Drawing.Color.Red;
            this.btnPc3.Location = new System.Drawing.Point(12, 65);
            this.btnPc3.Name = "btnPc3";
            this.btnPc3.Size = new System.Drawing.Size(55, 55);
            this.btnPc3.TabIndex = 2;
            this.btnPc3.Text = "PC3";
            this.btnPc3.UseVisualStyleBackColor = true;
            // 
            // btnPc4
            // 
            this.btnPc4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPc4.BackgroundImage")));
            this.btnPc4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPc4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPc4.ForeColor = System.Drawing.Color.Red;
            this.btnPc4.Location = new System.Drawing.Point(107, 65);
            this.btnPc4.Name = "btnPc4";
            this.btnPc4.Size = new System.Drawing.Size(55, 55);
            this.btnPc4.TabIndex = 3;
            this.btnPc4.Text = "PC4";
            this.btnPc4.UseVisualStyleBackColor = true;
            // 
            // btnPc5
            // 
            this.btnPc5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPc5.BackgroundImage")));
            this.btnPc5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPc5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPc5.ForeColor = System.Drawing.Color.Red;
            this.btnPc5.Location = new System.Drawing.Point(12, 126);
            this.btnPc5.Name = "btnPc5";
            this.btnPc5.Size = new System.Drawing.Size(55, 55);
            this.btnPc5.TabIndex = 4;
            this.btnPc5.Text = "PC5";
            this.btnPc5.UseVisualStyleBackColor = true;
            // 
            // btnPc6
            // 
            this.btnPc6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPc6.BackgroundImage")));
            this.btnPc6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPc6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPc6.ForeColor = System.Drawing.Color.Red;
            this.btnPc6.Location = new System.Drawing.Point(107, 126);
            this.btnPc6.Name = "btnPc6";
            this.btnPc6.Size = new System.Drawing.Size(55, 55);
            this.btnPc6.TabIndex = 5;
            this.btnPc6.Text = "PC6";
            this.btnPc6.UseVisualStyleBackColor = true;
            // 
            // Nudhoras
            // 
            this.Nudhoras.Location = new System.Drawing.Point(15, 210);
            this.Nudhoras.Name = "Nudhoras";
            this.Nudhoras.Size = new System.Drawing.Size(55, 20);
            this.Nudhoras.TabIndex = 6;
            // 
            // NudMinutos
            // 
            this.NudMinutos.Location = new System.Drawing.Point(107, 210);
            this.NudMinutos.Name = "NudMinutos";
            this.NudMinutos.Size = new System.Drawing.Size(55, 20);
            this.NudMinutos.TabIndex = 7;
            // 
            // txtCostoHora
            // 
            this.txtCostoHora.Location = new System.Drawing.Point(118, 236);
            this.txtCostoHora.Name = "txtCostoHora";
            this.txtCostoHora.Size = new System.Drawing.Size(100, 20);
            this.txtCostoHora.TabIndex = 8;
            // 
            // txtLibres
            // 
            this.txtLibres.Location = new System.Drawing.Point(15, 322);
            this.txtLibres.Name = "txtLibres";
            this.txtLibres.Size = new System.Drawing.Size(100, 20);
            this.txtLibres.TabIndex = 9;
            this.txtLibres.Text = "Libres:";
            // 
            // txtOcupadas
            // 
            this.txtOcupadas.Location = new System.Drawing.Point(15, 282);
            this.txtOcupadas.Name = "txtOcupadas";
            this.txtOcupadas.Size = new System.Drawing.Size(100, 20);
            this.txtOcupadas.TabIndex = 10;
            this.txtOcupadas.Text = "Ocupadas:";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 184);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 23);
            this.label1.TabIndex = 11;
            this.label1.Text = "Horas";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(95, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 23);
            this.label2.TabIndex = 12;
            this.label2.Text = "Minutos";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 13;
            this.label3.Text = "Costo Hora";
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(143, 298);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(75, 33);
            this.btnSalir.TabIndex = 14;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightGray;
            this.groupBox1.Controls.Add(this.lblUso1);
            this.groupBox1.Controls.Add(this.txtValorCob6);
            this.groupBox1.Controls.Add(this.txtTimeUs6);
            this.groupBox1.Controls.Add(this.txtTimeTot6);
            this.groupBox1.Controls.Add(this.txtTimeFal6);
            this.groupBox1.Controls.Add(this.txtValorCob5);
            this.groupBox1.Controls.Add(this.txtEstado6);
            this.groupBox1.Controls.Add(this.txtEstado3);
            this.groupBox1.Controls.Add(this.txtEstado4);
            this.groupBox1.Controls.Add(this.txtTimeFal4);
            this.groupBox1.Controls.Add(this.txtValorCob4);
            this.groupBox1.Controls.Add(this.txtEstado5);
            this.groupBox1.Controls.Add(this.txtTimeUs5);
            this.groupBox1.Controls.Add(this.txtTimeTot5);
            this.groupBox1.Controls.Add(this.txtTimeFal5);
            this.groupBox1.Controls.Add(this.txtTimeTot4);
            this.groupBox1.Controls.Add(this.txtValorCob3);
            this.groupBox1.Controls.Add(this.txtTimeU4);
            this.groupBox1.Controls.Add(this.txtTimeFal3);
            this.groupBox1.Controls.Add(this.txtTimeUs3);
            this.groupBox1.Controls.Add(this.txtTimeTot3);
            this.groupBox1.Controls.Add(this.txtTimeUs1);
            this.groupBox1.Controls.Add(this.txtTimeTot1);
            this.groupBox1.Controls.Add(this.txtTimeFal1);
            this.groupBox1.Controls.Add(this.txtValorCob1);
            this.groupBox1.Controls.Add(this.txtEstado2);
            this.groupBox1.Controls.Add(this.txtTimeUs2);
            this.groupBox1.Controls.Add(this.txtTimeTot2);
            this.groupBox1.Controls.Add(this.txtTimeFal2);
            this.groupBox1.Controls.Add(this.txtValorCob2);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtEstado1);
            this.groupBox1.Location = new System.Drawing.Point(246, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(668, 454);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Control General";
            // 
            // txtEstado1
            // 
            this.txtEstado1.Location = new System.Drawing.Point(153, 80);
            this.txtEstado1.Name = "txtEstado1";
            this.txtEstado1.Size = new System.Drawing.Size(69, 20);
            this.txtEstado1.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(28, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 24);
            this.label4.TabIndex = 17;
            this.label4.Text = "PC 01";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Location = new System.Drawing.Point(28, 139);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 24);
            this.label5.TabIndex = 18;
            this.label5.Text = "PC 02";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Location = new System.Drawing.Point(28, 203);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 25);
            this.label6.TabIndex = 19;
            this.label6.Text = "PC 03";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Location = new System.Drawing.Point(28, 264);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 20);
            this.label7.TabIndex = 20;
            this.label7.Text = "PC 04";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Location = new System.Drawing.Point(28, 313);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "PC 05";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Location = new System.Drawing.Point(28, 364);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 24);
            this.label9.TabIndex = 22;
            this.label9.Text = "PC 06";
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(153, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 18);
            this.label10.TabIndex = 23;
            this.label10.Text = "Estado";
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(242, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 32);
            this.label11.TabIndex = 24;
            this.label11.Text = "Tiempo de Uso";
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(341, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 18);
            this.label12.TabIndex = 25;
            this.label12.Text = "Tiempo Total";
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(458, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 32);
            this.label13.TabIndex = 26;
            this.label13.Text = "Tiempo Faltante";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(550, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 32);
            this.label14.TabIndex = 27;
            this.label14.Text = "Valor a cobrar";
            // 
            // txtValorCob2
            // 
            this.txtValorCob2.Location = new System.Drawing.Point(550, 141);
            this.txtValorCob2.Name = "txtValorCob2";
            this.txtValorCob2.Size = new System.Drawing.Size(69, 20);
            this.txtValorCob2.TabIndex = 28;
            // 
            // txtTimeFal2
            // 
            this.txtTimeFal2.Location = new System.Drawing.Point(458, 141);
            this.txtTimeFal2.Name = "txtTimeFal2";
            this.txtTimeFal2.Size = new System.Drawing.Size(69, 20);
            this.txtTimeFal2.TabIndex = 29;
            // 
            // txtTimeTot2
            // 
            this.txtTimeTot2.Location = new System.Drawing.Point(348, 141);
            this.txtTimeTot2.Name = "txtTimeTot2";
            this.txtTimeTot2.Size = new System.Drawing.Size(69, 20);
            this.txtTimeTot2.TabIndex = 30;
            // 
            // txtTimeUs2
            // 
            this.txtTimeUs2.Location = new System.Drawing.Point(245, 141);
            this.txtTimeUs2.Name = "txtTimeUs2";
            this.txtTimeUs2.Size = new System.Drawing.Size(86, 20);
            this.txtTimeUs2.TabIndex = 31;
            this.txtTimeUs2.Text = "00.00.00";
            // 
            // txtEstado2
            // 
            this.txtEstado2.Location = new System.Drawing.Point(153, 141);
            this.txtEstado2.Name = "txtEstado2";
            this.txtEstado2.Size = new System.Drawing.Size(69, 20);
            this.txtEstado2.TabIndex = 32;
            // 
            // txtValorCob1
            // 
            this.txtValorCob1.Location = new System.Drawing.Point(554, 80);
            this.txtValorCob1.Name = "txtValorCob1";
            this.txtValorCob1.Size = new System.Drawing.Size(69, 20);
            this.txtValorCob1.TabIndex = 33;
            // 
            // txtTimeFal1
            // 
            this.txtTimeFal1.Location = new System.Drawing.Point(458, 80);
            this.txtTimeFal1.Name = "txtTimeFal1";
            this.txtTimeFal1.Size = new System.Drawing.Size(69, 20);
            this.txtTimeFal1.TabIndex = 34;
            // 
            // txtTimeTot1
            // 
            this.txtTimeTot1.Location = new System.Drawing.Point(348, 80);
            this.txtTimeTot1.Name = "txtTimeTot1";
            this.txtTimeTot1.Size = new System.Drawing.Size(69, 20);
            this.txtTimeTot1.TabIndex = 35;
            // 
            // txtTimeUs1
            // 
            this.txtTimeUs1.Location = new System.Drawing.Point(242, 80);
            this.txtTimeUs1.Name = "txtTimeUs1";
            this.txtTimeUs1.Size = new System.Drawing.Size(89, 20);
            this.txtTimeUs1.TabIndex = 36;
            // 
            // txtTimeTot3
            // 
            this.txtTimeTot3.Location = new System.Drawing.Point(348, 198);
            this.txtTimeTot3.Name = "txtTimeTot3";
            this.txtTimeTot3.Size = new System.Drawing.Size(69, 20);
            this.txtTimeTot3.TabIndex = 37;
            // 
            // txtTimeUs3
            // 
            this.txtTimeUs3.Location = new System.Drawing.Point(245, 198);
            this.txtTimeUs3.Name = "txtTimeUs3";
            this.txtTimeUs3.Size = new System.Drawing.Size(86, 20);
            this.txtTimeUs3.TabIndex = 38;
            this.txtTimeUs3.Text = "00.00.00";
            // 
            // txtTimeFal3
            // 
            this.txtTimeFal3.Location = new System.Drawing.Point(458, 198);
            this.txtTimeFal3.Name = "txtTimeFal3";
            this.txtTimeFal3.Size = new System.Drawing.Size(69, 20);
            this.txtTimeFal3.TabIndex = 39;
            // 
            // txtTimeU4
            // 
            this.txtTimeU4.Location = new System.Drawing.Point(245, 268);
            this.txtTimeU4.Name = "txtTimeU4";
            this.txtTimeU4.Size = new System.Drawing.Size(86, 20);
            this.txtTimeU4.TabIndex = 40;
            this.txtTimeU4.Text = "00.00.00";
            // 
            // txtValorCob3
            // 
            this.txtValorCob3.Location = new System.Drawing.Point(554, 198);
            this.txtValorCob3.Name = "txtValorCob3";
            this.txtValorCob3.Size = new System.Drawing.Size(69, 20);
            this.txtValorCob3.TabIndex = 41;
            // 
            // txtTimeTot4
            // 
            this.txtTimeTot4.Location = new System.Drawing.Point(348, 262);
            this.txtTimeTot4.Name = "txtTimeTot4";
            this.txtTimeTot4.Size = new System.Drawing.Size(69, 20);
            this.txtTimeTot4.TabIndex = 42;
            // 
            // txtTimeFal5
            // 
            this.txtTimeFal5.Location = new System.Drawing.Point(458, 317);
            this.txtTimeFal5.Name = "txtTimeFal5";
            this.txtTimeFal5.Size = new System.Drawing.Size(69, 20);
            this.txtTimeFal5.TabIndex = 43;
            // 
            // txtTimeTot5
            // 
            this.txtTimeTot5.Location = new System.Drawing.Point(348, 318);
            this.txtTimeTot5.Name = "txtTimeTot5";
            this.txtTimeTot5.Size = new System.Drawing.Size(69, 20);
            this.txtTimeTot5.TabIndex = 44;
            // 
            // txtTimeUs5
            // 
            this.txtTimeUs5.Location = new System.Drawing.Point(245, 318);
            this.txtTimeUs5.Name = "txtTimeUs5";
            this.txtTimeUs5.Size = new System.Drawing.Size(86, 20);
            this.txtTimeUs5.TabIndex = 45;
            this.txtTimeUs5.Text = "00.00.00";
            // 
            // txtEstado5
            // 
            this.txtEstado5.Location = new System.Drawing.Point(153, 317);
            this.txtEstado5.Name = "txtEstado5";
            this.txtEstado5.Size = new System.Drawing.Size(69, 20);
            this.txtEstado5.TabIndex = 46;
            // 
            // txtValorCob4
            // 
            this.txtValorCob4.Location = new System.Drawing.Point(554, 268);
            this.txtValorCob4.Name = "txtValorCob4";
            this.txtValorCob4.Size = new System.Drawing.Size(69, 20);
            this.txtValorCob4.TabIndex = 47;
            // 
            // txtTimeFal4
            // 
            this.txtTimeFal4.Location = new System.Drawing.Point(458, 268);
            this.txtTimeFal4.Name = "txtTimeFal4";
            this.txtTimeFal4.Size = new System.Drawing.Size(69, 20);
            this.txtTimeFal4.TabIndex = 48;
            // 
            // txtEstado4
            // 
            this.txtEstado4.Location = new System.Drawing.Point(153, 265);
            this.txtEstado4.Name = "txtEstado4";
            this.txtEstado4.Size = new System.Drawing.Size(69, 20);
            this.txtEstado4.TabIndex = 49;
            // 
            // txtEstado3
            // 
            this.txtEstado3.Location = new System.Drawing.Point(153, 198);
            this.txtEstado3.Name = "txtEstado3";
            this.txtEstado3.Size = new System.Drawing.Size(69, 20);
            this.txtEstado3.TabIndex = 50;
            // 
            // txtEstado6
            // 
            this.txtEstado6.Location = new System.Drawing.Point(155, 372);
            this.txtEstado6.Name = "txtEstado6";
            this.txtEstado6.Size = new System.Drawing.Size(69, 20);
            this.txtEstado6.TabIndex = 51;
            // 
            // txtValorCob5
            // 
            this.txtValorCob5.Location = new System.Drawing.Point(550, 318);
            this.txtValorCob5.Name = "txtValorCob5";
            this.txtValorCob5.Size = new System.Drawing.Size(69, 20);
            this.txtValorCob5.TabIndex = 52;
            // 
            // txtTimeFal6
            // 
            this.txtTimeFal6.Location = new System.Drawing.Point(458, 372);
            this.txtTimeFal6.Name = "txtTimeFal6";
            this.txtTimeFal6.Size = new System.Drawing.Size(69, 20);
            this.txtTimeFal6.TabIndex = 53;
            // 
            // txtTimeTot6
            // 
            this.txtTimeTot6.Location = new System.Drawing.Point(348, 372);
            this.txtTimeTot6.Name = "txtTimeTot6";
            this.txtTimeTot6.Size = new System.Drawing.Size(69, 20);
            this.txtTimeTot6.TabIndex = 54;
            // 
            // txtTimeUs6
            // 
            this.txtTimeUs6.Location = new System.Drawing.Point(245, 374);
            this.txtTimeUs6.Name = "txtTimeUs6";
            this.txtTimeUs6.Size = new System.Drawing.Size(86, 20);
            this.txtTimeUs6.TabIndex = 55;
            this.txtTimeUs6.Text = "00.00.00";
            // 
            // txtValorCob6
            // 
            this.txtValorCob6.Location = new System.Drawing.Point(550, 372);
            this.txtValorCob6.Name = "txtValorCob6";
            this.txtValorCob6.Size = new System.Drawing.Size(69, 20);
            this.txtValorCob6.TabIndex = 56;
            // 
            // btn1
            // 
            btn1.BackColor = System.Drawing.Color.Transparent;
            btn1.ForeColor = System.Drawing.Color.Black;
            btn1.Location = new System.Drawing.Point(929, 77);
            btn1.Name = "btn1";
            btn1.Size = new System.Drawing.Size(51, 25);
            btn1.TabIndex = 57;
            btn1.Text = "01";
            btn1.UseVisualStyleBackColor = false;
            // 
            // btn5
            // 
            btn5.BackColor = System.Drawing.Color.Transparent;
            btn5.ForeColor = System.Drawing.Color.Black;
            btn5.Location = new System.Drawing.Point(929, 319);
            btn5.Name = "btn5";
            btn5.Size = new System.Drawing.Size(51, 25);
            btn5.TabIndex = 58;
            btn5.Text = "05";
            btn5.UseVisualStyleBackColor = false;
            // 
            // btn4
            // 
            btn4.BackColor = System.Drawing.Color.Transparent;
            btn4.ForeColor = System.Drawing.Color.Black;
            btn4.Location = new System.Drawing.Point(929, 266);
            btn4.Name = "btn4";
            btn4.Size = new System.Drawing.Size(51, 25);
            btn4.TabIndex = 59;
            btn4.Text = "04";
            btn4.UseVisualStyleBackColor = false;
            // 
            // btn3
            // 
            btn3.BackColor = System.Drawing.Color.Transparent;
            btn3.ForeColor = System.Drawing.Color.Black;
            btn3.Location = new System.Drawing.Point(929, 197);
            btn3.Name = "btn3";
            btn3.Size = new System.Drawing.Size(51, 25);
            btn3.TabIndex = 60;
            btn3.Text = "03";
            btn3.UseVisualStyleBackColor = false;
            // 
            // btn2
            // 
            btn2.BackColor = System.Drawing.Color.Transparent;
            btn2.ForeColor = System.Drawing.Color.Black;
            btn2.Location = new System.Drawing.Point(929, 140);
            btn2.Name = "btn2";
            btn2.Size = new System.Drawing.Size(51, 25);
            btn2.TabIndex = 61;
            btn2.Text = "02";
            btn2.UseVisualStyleBackColor = false;
            // 
            // btn6
            // 
            btn6.BackColor = System.Drawing.Color.Transparent;
            btn6.ForeColor = System.Drawing.Color.Black;
            btn6.Location = new System.Drawing.Point(929, 373);
            btn6.Name = "btn6";
            btn6.Size = new System.Drawing.Size(51, 25);
            btn6.TabIndex = 62;
            btn6.Text = "06";
            btn6.UseVisualStyleBackColor = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(963, 421);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(34, 13);
            this.label15.TabIndex = 63;
            this.label15.Text = "Total:";
            // 
            // lst
            // 
            this.lst.FormattingEnabled = true;
            this.lst.Location = new System.Drawing.Point(1002, 39);
            this.lst.Name = "lst";
            this.lst.Size = new System.Drawing.Size(195, 342);
            this.lst.TabIndex = 64;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(999, 23);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(104, 13);
            this.label16.TabIndex = 65;
            this.label16.Text = "Ingreso por Máquina";
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(1019, 418);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.TabIndex = 66;
            // 
            // TimeInicio
            // 
            this.TimeInicio.Tick += new System.EventHandler(this.TimeInicio_Tick);
            // 
            // Nudsegundos
            // 
            this.Nudsegundos.Location = new System.Drawing.Point(168, 210);
            this.Nudsegundos.Name = "Nudsegundos";
            this.Nudsegundos.Size = new System.Drawing.Size(55, 20);
            this.Nudsegundos.TabIndex = 67;
            // 
            // lblUso1
            // 
            this.lblUso1.BackColor = System.Drawing.Color.White;
            this.lblUso1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblUso1.Location = new System.Drawing.Point(242, 103);
            this.lblUso1.Name = "lblUso1";
            this.lblUso1.Size = new System.Drawing.Size(89, 23);
            this.lblUso1.TabIndex = 57;
            this.lblUso1.Text = "00.00.00";
            // 
            // TimePC1
            // 
            this.TimePC1.Tick += new System.EventHandler(this.TimePC1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1209, 519);
            this.Controls.Add(this.Nudsegundos);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.lst);
            this.Controls.Add(this.label15);
            this.Controls.Add(btn6);
            this.Controls.Add(btn2);
            this.Controls.Add(btn3);
            this.Controls.Add(btn4);
            this.Controls.Add(btn5);
            this.Controls.Add(btn1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtOcupadas);
            this.Controls.Add(this.txtLibres);
            this.Controls.Add(this.txtCostoHora);
            this.Controls.Add(this.NudMinutos);
            this.Controls.Add(this.Nudhoras);
            this.Controls.Add(this.btnPc6);
            this.Controls.Add(this.btnPc5);
            this.Controls.Add(this.btnPc4);
            this.Controls.Add(this.btnPc3);
            this.Controls.Add(this.btnPc2);
            this.Controls.Add(this.btnPc1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Nudhoras)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NudMinutos)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Nudsegundos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPc1;
        private System.Windows.Forms.Button btnPc2;
        private System.Windows.Forms.Button btnPc3;
        private System.Windows.Forms.Button btnPc4;
        private System.Windows.Forms.Button btnPc5;
        private System.Windows.Forms.Button btnPc6;
        private System.Windows.Forms.NumericUpDown Nudhoras;
        private System.Windows.Forms.NumericUpDown NudMinutos;
        private System.Windows.Forms.TextBox txtCostoHora;
        private System.Windows.Forms.TextBox txtLibres;
        private System.Windows.Forms.TextBox txtOcupadas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtValorCob6;
        private System.Windows.Forms.TextBox txtTimeUs6;
        private System.Windows.Forms.TextBox txtTimeTot6;
        private System.Windows.Forms.TextBox txtTimeFal6;
        private System.Windows.Forms.TextBox txtValorCob5;
        private System.Windows.Forms.TextBox txtEstado6;
        private System.Windows.Forms.TextBox txtEstado3;
        private System.Windows.Forms.TextBox txtEstado4;
        private System.Windows.Forms.TextBox txtTimeFal4;
        private System.Windows.Forms.TextBox txtValorCob4;
        private System.Windows.Forms.TextBox txtEstado5;
        private System.Windows.Forms.TextBox txtTimeUs5;
        private System.Windows.Forms.TextBox txtTimeTot5;
        private System.Windows.Forms.TextBox txtTimeFal5;
        private System.Windows.Forms.TextBox txtTimeTot4;
        private System.Windows.Forms.TextBox txtValorCob3;
        private System.Windows.Forms.TextBox txtTimeU4;
        private System.Windows.Forms.TextBox txtTimeFal3;
        private System.Windows.Forms.TextBox txtTimeUs3;
        private System.Windows.Forms.TextBox txtTimeTot3;
        private System.Windows.Forms.TextBox txtTimeUs1;
        private System.Windows.Forms.TextBox txtTimeTot1;
        private System.Windows.Forms.TextBox txtTimeFal1;
        private System.Windows.Forms.TextBox txtValorCob1;
        private System.Windows.Forms.TextBox txtEstado2;
        private System.Windows.Forms.TextBox txtTimeUs2;
        private System.Windows.Forms.TextBox txtTimeTot2;
        private System.Windows.Forms.TextBox txtTimeFal2;
        private System.Windows.Forms.TextBox txtValorCob2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtEstado1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ListBox lst;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Timer TimeInicio;
        private System.Windows.Forms.NumericUpDown Nudsegundos;
        private System.Windows.Forms.Label lblUso1;
        private System.Windows.Forms.Timer TimePC1;
    }
}

