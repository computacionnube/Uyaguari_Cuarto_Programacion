﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FORMULARIO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnejer1_Click(object sender, EventArgs e)
        {
            frmEjer1 objEjer1 = new frmEjer1();
            objEjer1.Text = "EJERCICIO DE AREGLOS";
            objEjer1.MaximizeBox = false;//para bloquear maximizar al ejercicio 1
            objEjer1.Show();
           
        }

        private void btnejer2_Click(object sender, EventArgs e)
        {
            frmEjer2 objEjer2 = new frmEjer2();
            objEjer2.Text = "FORMULARIO MAXIMIZADO ";//maximizar el objeto
            objEjer2.WindowState = FormWindowState.Maximized;
            objEjer2.Show();
        }

        private void btnejer3_Click(object sender, EventArgs e)
        {
            frmEjer3 objEjer3 = new frmEjer3();
            this.Hide();//hide es para ocultar 
            objEjer3.ShowDialog();//showdialog es un cuadro de dialogo mientras no lo cierras no puede funcionar y no deja trabajar con mas dialogos
            this.Visible = true;//lo hace visible al dialogo oculto
        }

        private void btnejer4_Click(object sender, EventArgs e)
        {
            frmEjer4 objEjer4 = new frmEjer4();
            objEjer4.ShowDialog();//cuadro de dialogo
        }

       
    }
}
