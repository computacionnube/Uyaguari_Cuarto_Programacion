﻿namespace MENUS
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.vECTORESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uNIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNTERSECCIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.dIFERENCIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mATRICESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cUADRADAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lATINAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cUADRADOMAGICOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sALIRToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.Color1 = new System.Windows.Forms.Label();
            this.vsbVerde = new System.Windows.Forms.VScrollBar();
            this.vsbAzul = new System.Windows.Forms.VScrollBar();
            this.vsbRojo = new System.Windows.Forms.VScrollBar();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.hsbAncho = new System.Windows.Forms.HScrollBar();
            this.vsbBajo = new System.Windows.Forms.VScrollBar();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vECTORESToolStripMenuItem,
            this.mATRICESToolStripMenuItem,
            this.sALIRToolStripMenuItem,
            this.toolStripComboBox1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(849, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // vECTORESToolStripMenuItem
            // 
            this.vECTORESToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.vECTORESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.uNIONToolStripMenuItem,
            this.iNTERSECCIONToolStripMenuItem,
            this.toolStripMenuItem2,
            this.dIFERENCIAToolStripMenuItem});
            this.vECTORESToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("vECTORESToolStripMenuItem.Image")));
            this.vECTORESToolStripMenuItem.Name = "vECTORESToolStripMenuItem";
            this.vECTORESToolStripMenuItem.Size = new System.Drawing.Size(91, 23);
            this.vECTORESToolStripMenuItem.Text = "&VECTORES";
            // 
            // uNIONToolStripMenuItem
            // 
            this.uNIONToolStripMenuItem.Checked = true;
            this.uNIONToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.uNIONToolStripMenuItem.Name = "uNIONToolStripMenuItem";
            this.uNIONToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.uNIONToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.uNIONToolStripMenuItem.Text = "UNION";
            this.uNIONToolStripMenuItem.Click += new System.EventHandler(this.uNIONToolStripMenuItem_Click);
            // 
            // iNTERSECCIONToolStripMenuItem
            // 
            this.iNTERSECCIONToolStripMenuItem.Name = "iNTERSECCIONToolStripMenuItem";
            this.iNTERSECCIONToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.iNTERSECCIONToolStripMenuItem.Text = "INTERSECCION";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(152, 6);
            // 
            // dIFERENCIAToolStripMenuItem
            // 
            this.dIFERENCIAToolStripMenuItem.Name = "dIFERENCIAToolStripMenuItem";
            this.dIFERENCIAToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.dIFERENCIAToolStripMenuItem.Text = "DIFERENCIA";
            // 
            // mATRICESToolStripMenuItem
            // 
            this.mATRICESToolStripMenuItem.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.mATRICESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cUADRADAToolStripMenuItem,
            this.lATINAToolStripMenuItem,
            this.cUADRADOMAGICOToolStripMenuItem});
            this.mATRICESToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("mATRICESToolStripMenuItem.Image")));
            this.mATRICESToolStripMenuItem.Name = "mATRICESToolStripMenuItem";
            this.mATRICESToolStripMenuItem.Size = new System.Drawing.Size(91, 23);
            this.mATRICESToolStripMenuItem.Text = "&MATRICES";
            // 
            // cUADRADAToolStripMenuItem
            // 
            this.cUADRADAToolStripMenuItem.Name = "cUADRADAToolStripMenuItem";
            this.cUADRADAToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.cUADRADAToolStripMenuItem.Text = "CUADRADA";
            // 
            // lATINAToolStripMenuItem
            // 
            this.lATINAToolStripMenuItem.Name = "lATINAToolStripMenuItem";
            this.lATINAToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.lATINAToolStripMenuItem.Text = "LATINA";
            this.lATINAToolStripMenuItem.ToolTipText = "Cuadrado Latina";
            // 
            // cUADRADOMAGICOToolStripMenuItem
            // 
            this.cUADRADOMAGICOToolStripMenuItem.Name = "cUADRADOMAGICOToolStripMenuItem";
            this.cUADRADOMAGICOToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.cUADRADOMAGICOToolStripMenuItem.Size = new System.Drawing.Size(230, 22);
            this.cUADRADOMAGICOToolStripMenuItem.Text = "CUADRADO MAGICO";
            this.cUADRADOMAGICOToolStripMenuItem.Click += new System.EventHandler(this.cUADRADOMAGICOToolStripMenuItem_Click);
            // 
            // sALIRToolStripMenuItem
            // 
            this.sALIRToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.sALIRToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sALIRToolStripMenuItem.Image")));
            this.sALIRToolStripMenuItem.Name = "sALIRToolStripMenuItem";
            this.sALIRToolStripMenuItem.Size = new System.Drawing.Size(65, 23);
            this.sALIRToolStripMenuItem.Text = "&SALIR";
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Items.AddRange(new object[] {
            "serie 1",
            "serie 2",
            "serie 3"});
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 23);
            this.toolStripComboBox1.Text = "serie ";
            this.toolStripComboBox1.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox1_SelectedIndexChanged);
            this.toolStripComboBox1.Click += new System.EventHandler(this.toolStripComboBox1_Click);
            // 
            // Color1
            // 
            this.Color1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Color1.Location = new System.Drawing.Point(133, 112);
            this.Color1.Name = "Color1";
            this.Color1.Size = new System.Drawing.Size(183, 109);
            this.Color1.TabIndex = 1;
            // 
            // vsbVerde
            // 
            this.vsbVerde.LargeChange = 5;
            this.vsbVerde.Location = new System.Drawing.Point(41, 112);
            this.vsbVerde.Maximum = 255;
            this.vsbVerde.Name = "vsbVerde";
            this.vsbVerde.Size = new System.Drawing.Size(17, 240);
            this.vsbVerde.TabIndex = 2;
            this.vsbVerde.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbVerde_Scroll);
            // 
            // vsbAzul
            // 
            this.vsbAzul.Location = new System.Drawing.Point(76, 112);
            this.vsbAzul.Maximum = 255;
            this.vsbAzul.Name = "vsbAzul";
            this.vsbAzul.Size = new System.Drawing.Size(17, 240);
            this.vsbAzul.TabIndex = 3;
            this.vsbAzul.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbAzul_Scroll);
            // 
            // vsbRojo
            // 
            this.vsbRojo.LargeChange = 5;
            this.vsbRojo.Location = new System.Drawing.Point(13, 112);
            this.vsbRojo.Maximum = 255;
            this.vsbRojo.Name = "vsbRojo";
            this.vsbRojo.Size = new System.Drawing.Size(17, 240);
            this.vsbRojo.SmallChange = 5;
            this.vsbRojo.TabIndex = 2;
            this.vsbRojo.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbRojo_Scroll);
            // 
            // pb1
            // 
            this.pb1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pb1.BackgroundImage")));
            this.pb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pb1.Location = new System.Drawing.Point(486, 129);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(60, 60);
            this.pb1.TabIndex = 4;
            this.pb1.TabStop = false;
            // 
            // hsbAncho
            // 
            this.hsbAncho.Location = new System.Drawing.Point(486, 84);
            this.hsbAncho.Name = "hsbAncho";
            this.hsbAncho.Size = new System.Drawing.Size(171, 17);
            this.hsbAncho.TabIndex = 5;
            this.hsbAncho.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hsbAncho_Scroll);
            // 
            // vsbBajo
            // 
            this.vsbBajo.Location = new System.Drawing.Point(435, 129);
            this.vsbBajo.Name = "vsbBajo";
            this.vsbBajo.Size = new System.Drawing.Size(17, 126);
            this.vsbBajo.TabIndex = 6;
            this.vsbBajo.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbBajo_Scroll);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 435);
            this.Controls.Add(this.vsbBajo);
            this.Controls.Add(this.hsbAncho);
            this.Controls.Add(this.pb1);
            this.Controls.Add(this.vsbRojo);
            this.Controls.Add(this.vsbAzul);
            this.Controls.Add(this.vsbVerde);
            this.Controls.Add(this.Color1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "<";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem vECTORESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uNIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNTERSECCIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mATRICESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sALIRToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem dIFERENCIAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cUADRADAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lATINAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cUADRADOMAGICOToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.Label Color1;
        private System.Windows.Forms.VScrollBar vsbVerde;
        private System.Windows.Forms.VScrollBar vsbAzul;
        private System.Windows.Forms.VScrollBar vsbRojo;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.HScrollBar hsbAncho;
        private System.Windows.Forms.VScrollBar vsbBajo;
    }
}

