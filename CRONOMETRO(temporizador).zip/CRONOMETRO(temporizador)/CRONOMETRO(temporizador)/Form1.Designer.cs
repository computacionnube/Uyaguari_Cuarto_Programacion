﻿namespace CRONOMETRO_temporizador_
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btniniciar = new System.Windows.Forms.Button();
            this.btndetener = new System.Windows.Forms.Button();
            this.btnencerar = new System.Windows.Forms.Button();
            this.txttiempo = new System.Windows.Forms.TextBox();
            this.reloj = new System.Windows.Forms.Timer(this.components);
            this.lbltienpo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpreloj = new System.Windows.Forms.DateTimePicker();
            this.alarma = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.dtpFijarH = new System.Windows.Forms.DateTimePicker();
            this.btnalarma = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.nupdhora = new System.Windows.Forms.NumericUpDown();
            this.nupdsegundo = new System.Windows.Forms.NumericUpDown();
            this.nupdminuto = new System.Windows.Forms.NumericUpDown();
            this.btnactivar = new System.Windows.Forms.Button();
            this.btndescativar = new System.Windows.Forms.Button();
            this.bomba = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nupdhora)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupdsegundo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupdminuto)).BeginInit();
            this.SuspendLayout();
            // 
            // btniniciar
            // 
            this.btniniciar.Location = new System.Drawing.Point(12, 40);
            this.btniniciar.Name = "btniniciar";
            this.btniniciar.Size = new System.Drawing.Size(75, 23);
            this.btniniciar.TabIndex = 0;
            this.btniniciar.Text = "INICIAR";
            this.btniniciar.UseVisualStyleBackColor = true;
            this.btniniciar.Click += new System.EventHandler(this.btniniciar_Click);
            // 
            // btndetener
            // 
            this.btndetener.Location = new System.Drawing.Point(111, 40);
            this.btndetener.Name = "btndetener";
            this.btndetener.Size = new System.Drawing.Size(75, 23);
            this.btndetener.TabIndex = 1;
            this.btndetener.Text = "DETENER";
            this.btndetener.UseVisualStyleBackColor = true;
            this.btndetener.Click += new System.EventHandler(this.btndetener_Click);
            // 
            // btnencerar
            // 
            this.btnencerar.Location = new System.Drawing.Point(209, 40);
            this.btnencerar.Name = "btnencerar";
            this.btnencerar.Size = new System.Drawing.Size(75, 23);
            this.btnencerar.TabIndex = 2;
            this.btnencerar.Text = "ENCERAR";
            this.btnencerar.UseVisualStyleBackColor = true;
            this.btnencerar.Click += new System.EventHandler(this.btnencerar_Click);
            // 
            // txttiempo
            // 
            this.txttiempo.Location = new System.Drawing.Point(111, 101);
            this.txttiempo.Name = "txttiempo";
            this.txttiempo.Size = new System.Drawing.Size(100, 20);
            this.txttiempo.TabIndex = 3;
            this.txttiempo.Text = "00:00:00.0";
            // 
            // reloj
            // 
            this.reloj.Tick += new System.EventHandler(this.reloj_Tick);
            // 
            // lbltienpo
            // 
            this.lbltienpo.AutoSize = true;
            this.lbltienpo.Location = new System.Drawing.Point(39, 104);
            this.lbltienpo.Name = "lbltienpo";
            this.lbltienpo.Size = new System.Drawing.Size(48, 13);
            this.lbltienpo.TabIndex = 4;
            this.lbltienpo.Text = "TIEMPO";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Reloj";
            // 
            // dtpreloj
            // 
            this.dtpreloj.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpreloj.Location = new System.Drawing.Point(93, 149);
            this.dtpreloj.Name = "dtpreloj";
            this.dtpreloj.Size = new System.Drawing.Size(93, 20);
            this.dtpreloj.TabIndex = 6;
            // 
            // alarma
            // 
            this.alarma.Enabled = true;
            this.alarma.Tick += new System.EventHandler(this.alarma_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Fijar Hora";
            // 
            // dtpFijarH
            // 
            this.dtpFijarH.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpFijarH.Location = new System.Drawing.Point(95, 192);
            this.dtpFijarH.Name = "dtpFijarH";
            this.dtpFijarH.ShowUpDown = true;
            this.dtpFijarH.Size = new System.Drawing.Size(91, 20);
            this.dtpFijarH.TabIndex = 8;
            // 
            // btnalarma
            // 
            this.btnalarma.Location = new System.Drawing.Point(209, 157);
            this.btnalarma.Name = "btnalarma";
            this.btnalarma.Size = new System.Drawing.Size(75, 47);
            this.btnalarma.TabIndex = 9;
            this.btnalarma.Text = "FIJAR ALARMA";
            this.btnalarma.UseVisualStyleBackColor = true;
            this.btnalarma.Click += new System.EventHandler(this.btnalarma_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 258);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "label3";
            // 
            // nupdhora
            // 
            this.nupdhora.Location = new System.Drawing.Point(114, 251);
            this.nupdhora.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.nupdhora.Name = "nupdhora";
            this.nupdhora.Size = new System.Drawing.Size(31, 20);
            this.nupdhora.TabIndex = 11;
            // 
            // nupdsegundo
            // 
            this.nupdsegundo.Location = new System.Drawing.Point(216, 251);
            this.nupdsegundo.Name = "nupdsegundo";
            this.nupdsegundo.Size = new System.Drawing.Size(31, 20);
            this.nupdsegundo.TabIndex = 12;
            // 
            // nupdminuto
            // 
            this.nupdminuto.Location = new System.Drawing.Point(168, 251);
            this.nupdminuto.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.nupdminuto.Name = "nupdminuto";
            this.nupdminuto.Size = new System.Drawing.Size(31, 20);
            this.nupdminuto.TabIndex = 14;
            // 
            // btnactivar
            // 
            this.btnactivar.Location = new System.Drawing.Point(288, 248);
            this.btnactivar.Name = "btnactivar";
            this.btnactivar.Size = new System.Drawing.Size(75, 23);
            this.btnactivar.TabIndex = 15;
            this.btnactivar.Text = "ACTIVAR";
            this.btnactivar.UseVisualStyleBackColor = true;
            this.btnactivar.Click += new System.EventHandler(this.btnactivar_Click);
            // 
            // btndescativar
            // 
            this.btndescativar.Location = new System.Drawing.Point(288, 290);
            this.btndescativar.Name = "btndescativar";
            this.btndescativar.Size = new System.Drawing.Size(75, 23);
            this.btndescativar.TabIndex = 16;
            this.btndescativar.Text = "DESACTIVAR";
            this.btndescativar.UseVisualStyleBackColor = true;
            this.btndescativar.Click += new System.EventHandler(this.btndescativar_Click);
            // 
            // bomba
            // 
            this.bomba.Tick += new System.EventHandler(this.bomba_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(573, 346);
            this.Controls.Add(this.btndescativar);
            this.Controls.Add(this.btnactivar);
            this.Controls.Add(this.nupdminuto);
            this.Controls.Add(this.nupdsegundo);
            this.Controls.Add(this.nupdhora);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnalarma);
            this.Controls.Add(this.dtpFijarH);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpreloj);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbltienpo);
            this.Controls.Add(this.txttiempo);
            this.Controls.Add(this.btnencerar);
            this.Controls.Add(this.btndetener);
            this.Controls.Add(this.btniniciar);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nupdhora)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupdsegundo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupdminuto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btniniciar;
        private System.Windows.Forms.Button btndetener;
        private System.Windows.Forms.Button btnencerar;
        private System.Windows.Forms.TextBox txttiempo;
        private System.Windows.Forms.Timer reloj;
        private System.Windows.Forms.Label lbltienpo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpreloj;
        private System.Windows.Forms.Timer alarma;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpFijarH;
        private System.Windows.Forms.Button btnalarma;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nupdhora;
        private System.Windows.Forms.NumericUpDown nupdsegundo;
        private System.Windows.Forms.NumericUpDown nupdminuto;
        private System.Windows.Forms.Button btnactivar;
        private System.Windows.Forms.Button btndescativar;
        private System.Windows.Forms.Timer bomba;
    }
}

