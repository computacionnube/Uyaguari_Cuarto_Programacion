﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MENUS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int ancho, largo;

        private void uNIONToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (iNTERSECCIONToolStripMenuItem.Checked == true)
            {
                MessageBox.Show("activo");
                iNTERSECCIONToolStripMenuItem.Checked = false;
            }
            else
            {
                MessageBox.Show("desactivo");
                iNTERSECCIONToolStripMenuItem.Checked = true;

            }
        }

        private void cUADRADOMAGICOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("prra");

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {



        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (toolStripComboBox1.SelectedIndex == 0)
                MessageBox.Show("SERIE BASICA");
            else if (toolStripComboBox1.SelectedIndex == 1)
                MessageBox.Show("SERIE MEDIA");
            else if (toolStripComboBox1.SelectedIndex == 2)
                MessageBox.Show("serie completa");

        }

        private void vsbRojo_Scroll(object sender, ScrollEventArgs e)
        {
            Color1.BackColor = Color.FromArgb(vsbRojo.Value, vsbAzul.Value, vsbVerde.Value);
        }

        private void vsbVerde_Scroll(object sender, ScrollEventArgs e)
        {
            Color1.BackColor = Color.FromArgb(vsbRojo.Value, vsbAzul.Value, vsbVerde.Value);
        }

        private void vsbAzul_Scroll(object sender, ScrollEventArgs e)
        {
            Color1.BackColor = Color.FromArgb(vsbRojo.Value, vsbAzul.Value, vsbVerde.Value);
        }

        private void hsbAncho_Scroll(object sender, ScrollEventArgs e)
        {
            ancho = 60 + hsbAncho.Value; pb1.Size = new Size(ancho, largo);
        }

        private void vsbBajo_Scroll(object sender, ScrollEventArgs e)
        {
            largo = 60 + vsbBajo.Value;
            pb1.Size = new Size(ancho,largo);
        }
    }
}

      
        
    
      

