﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FORMULARIO
{
    public partial class frmEjer2 : Form
    {
        public frmEjer2()
        {
            InitializeComponent();
        }
        int img = 0;
        private void btnCierra2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void relojPantalla_Tick(object sender, EventArgs e)
        {
            pantalla.Image = lstImagen.Images[img];//movimiento de imagenes
            img++;
            if (img == 7) img = 0;
        }

       
    }
}
